# FULL MIGRATION — new server, continue from here
Trigger: user sends migrate-part-* files and says «مهسا برگرد».

1. Join parts: `cat migrate-part-* > migrate-full.tgz`, extract to /root:
   `tar -xzf migrate-full.tgz -C /` (contains .hermes/ + dollar_card.py + fonts/).
2. Install base: hermes-agent, python3, pip packages:
   `pip install pillow edge-tts yt-dlp faster-whisper ShazamAPI`
3. Restore secrets: .hermes/.env + .hermes/config.yaml are inside (tokens,
   model, TTS voice, allowed users). Verify TELEGRAM_BOT_TOKEN present.
4. Load memory: read .hermes/memories/USER.md + MEMORY.md + SOUL.md, load
   each § section into the memory tool (user + memory targets).
5. Recreate cron jobs from .hermes/backups/jobs-manifest.json (or the
   manifest inside tgz): dollar-hourly, dollar-midnight, memory-backup,
   pairing-watch — all no_agent, deliver=origin, attach.
6. Restart daemons: pairing_daemon.py (3s poll) + chat_mirror.py (5s poll)
   in background with output to .hermes/*.log.
7. Verify: `py_compile` scripts, run memory_backup.py (2nd run silent),
   test dollar card render, check `hermes pairing list` shows approvals,
   confirm gateway multiplex + guest profile route intact.
8. Tell Parham: «برگشتم عشقم» + what was verified.
