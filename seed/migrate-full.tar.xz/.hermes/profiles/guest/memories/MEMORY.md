Guest profile notes (neutral, per-guest; never Parham's data).
