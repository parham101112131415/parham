# Free Iranian FX Rate Sources — USD/IRR Tehran (verified 2026-09-03)

Working feeds for the Tehran free-market USD rate (دلار آزاد). No API keys, no auth. All values parsed with plain `urllib` + regex from Termux/Android.

## Endpoints

| Source | URL | Fields | Units |
|---|---|---|---|
| TGJU JSON | `https://call1.tgju.org/ajax.json` | `current.price_dollar_rl` → `p` (last), `h` (high), `l` (low), `t_en`/`ts` (timestamp) | RIAL — divide by 10 for toman |
| alanchand.com | `https://alanchand.com/currencies-price` (HTML) | row «دلار آمریکا» → first two numbers after the label = buy, sell | TOMAN as published |

Note the asymmetry: TGJU publishes rial, alanchand publishes toman. Converting both with a global /10 (or neither) is the classic bug.

## Parsing recipe — alanchand (buy/sell)

```python
import re, urllib.request

def get_usd_buy_sell():
    req = urllib.request.Request('https://alanchand.com/currencies-price',
                                 headers={'User-Agent': 'Mozilla/5.0'})
    html = urllib.request.urlopen(req, timeout=25).read().decode('utf-8', 'ignore')
    txt = re.sub(r'<[^>]+>', ' ', html)   # strip tags to SPACES, not '|'
    i = txt.find('دلار آمریکا')
    if i < 0:
        return None
    nums = re.findall(r'[۰-۹0-9][۰-۹0-9,\.]*', txt[i:i+300])[:2]
    return nums[0], nums[1]  # buy, sell (toman, Persian digits — translate first)
```

Stripping tags to `|` broke parsing here: numbers sit in separate table rows with newlines/whitespace between pipes, so `|`-adjacent regexes match nothing. Spaces + a 300-char window work.

## Persian digit translation (required before parsing)

```python
TABLE = str.maketrans('\u06f0\u06f1\u06f2\u06f3\u06f4\u06f5\u06f6\u06f7\u06f8\u06f9'
                      '\u0660\u0661\u0662\u0663\u0664\u0665\u0666\u0667\u0668\u0669',
                      '01234567890123456789')
```

## Stale-symbol trap in TGJU's aggregated JSON

`current` holds 963 entries including years-dead legacy symbols. Verified 2026-09-03:

- `price_dollar_future` — last update 2018 (NOT a live «دلار فردا» feed)
- `price_dollar_sm` — 2020; `price_dollar_ex` — 2022; `usdt-irr` — 2020
- LIVE: `price_dollar_rl` (and `price_dollar_dt`, identical values), timestamp current

Always check `t_en`/`ts` freshness before trusting any symbol.

## «دلار فردا» naming reality

No Iranian source publishes a live separate «دلار فردا» symbol (TGJU full-page scan + grep for «فردا» in ajax.json = 0 hits; alanchand has no such row). Market channels reporting "دلار فردایی" quote the free-market rate. Label output with the user's preferred wording but source it from the free-market feed, and tell the user once what backs the numbers.

## Sources that did NOT work (as of 2026-09-03 — environment-dependent, retest)

- `snar.ir` — DNS does not resolve from this network.
- `tgju.org/profile/*` pages and `api.tgju.org/v1/*` — 404 from this network while `call1.tgju.org/ajax.json` works.
- `bonbast.com` — HTML loads but prices are not in the raw HTML (JS-rendered); needs browser tooling.

## Proven cron delivery pattern (Hermes, validated live)

1. Script at `~/.hermes/scripts/fetch_dollar.py`, modes: `now` (snapshot + hourly message) and `summary` (yesterday digest). Working copy at `~/.hermes/dollar/` for manual runs.
2. State: `~/.hermes/dollar/dollar_log.jsonl` (append-only, every observation) + `dollar_day.json` (current day bucket).
3. Jobs (no_agent=true, deliver='origin', attach_to_session=true):
   - Hourly snapshots: cron `0 9-23 * * *` → `fetch_dollar.py` (job id 245343cf4f4d)
   - Midnight digest: cron `0 0 * * *` → `dollar_summary.py` wrapper (job id 351b91437c7a)
4. Digest boundary: at 00:00 the date has rolled, so summary mode reads YESTERDAY's `greg` bucket, falls back to rebuilding from the JSONL log, then resets the bucket. Verified with synthetic log data reproducing the target format exactly.
5. Cron `script=` must be a bare filename inside `~/.hermes/scripts/` — absolute or home-relative paths are refused.

Hourly output format (user-approved):

```
دلار فردایی تهران ⏳ 218,700 خــرید🔵
دلار فردایی تهران ⏳ 220,900 فروش🔴

📍 تهران | پنجشنبه 05:25
TGJU — last 219,900 | high 220,520 | low 216,700
```

Digest format (user-approved):

```
📌 پایان معاملات

🗓 چهارشنبه | 1405.06.11
✅ شروع معاملات: 221,000
📈 سقف معاملات: 221,000
📉 کف معاملات: 216,500
⏳ آخرین معامله: 220,200
```

Jalali dates: embed the standard algorithmic gregorian→jalali converter (jdatetime not installed in Termux).
