---
name: iran-fx-rates
description: "Use when Iranian FX rates (دلار) are requested or scheduled."
version: 1.0.0
license: MIT
metadata:
  hermes:
    tags: [FX, Iran, USD, Toman, Tehran, Scheduling, Telegram]
    related_skills: [product-price-monitor]
---

# Iranian FX Rates (USD/Toman)

Fetch Tehran free-market currency rates from key-free Iranian sources, parse them reliably (mixed units, Persian digits), and deliver them as scheduled reports (hourly snapshots, midnight digests) via Hermes cron jobs with `no_agent` scripts. Related umbrella: `product-price-monitor` (covers threshold-alert watches; this skill covers Iranian FX specifics and the fixed-format snapshot pattern).

## When to Use

- "قیمت دلار چنده؟" / current USD-Tehran rate lookup.
- Scheduled rate reporting: "هر ساعت قیمت دلار رو بفرست" / hourly snapshots, end-of-day digests.
- Any Iranian market rate needing buy/sell (خرید/فروش) separation.

## Source Map (verified 2026-09-03)

| Need | Source | Notes |
|---|---|---|
| daily OHLC | `https://call1.tgju.org/ajax.json` → `current.price_dollar_rl` | JSON, RIAL (÷10). DAILY snapshot — `ts` can sit on the previous day mid-session; never present as intraday |
| live sarafi sell | same ajax.json → `current.sabaexchange_usd_sell` | RIAL (÷10). Freshest same-day tick (`ts`/`t_en`) — best intraday second source; buy-side absent (…_usd_buy = None) |
| buy/sell | `https://alanchand.com/currencies-price` | HTML table, TOMAN as published; first two numbers after «دلار آمریکا» |

Full endpoint details, parsing recipes, stale-symbol traps, dead sources, and the proven cron setup: `references/iran-fx-usd-sources.md`.

## Key Facts

- **No live «دلار فردا» symbol exists.** TGJU's `price_dollar_future` is dead (2018); grep for «فردا» in the feed = 0 hits. Channels quoting "دلار فردایی" use the free-market rate. Honor the user's label wording, source from `price_dollar_rl` + alanchand, and tell the user once so they know what backs the numbers.
- **Unit asymmetry is the classic bug**: TGJU publishes rial, alanchand publishes toman. Normalize per source, never globally.
- **Translate Persian digits (۰-۹, U+06F0-U+06F9 / U+0660-U+0669) to ASCII before any numeric parse.**
- **Jalali dates**: `jdatetime` is not installed in Termux; embed the standard algorithmic gregorian→jalali converter.
- **Surface source freshness in every message**: show the hour AND the source's own declared update time (alanchand prints «آخرین بروز رسانی HH:MM» in-page; TGJU ticks carry `t_en`). A flat market then reads as "quiet, verified" instead of "broken fetch".
- **Prices can legitimately be flat for hours** — verified: alanchand 218,700/220,900 unchanged 05:25→10:15 on a quiet Thursday while the saba tick only moved once (09:38). Flatness is not evidence of a stale pipeline; no update timestamp in the output IS.

## Scheduled-Report Pattern (validated)

1. Write ONE self-contained script (stdlib only: `urllib`, `re`, `json`) with two modes: snapshot (`now`) and digest (`summary`). Print the EXACT user-approved message format from stdout. Test both modes in the foreground before scheduling anything.
2. Script location: `~/.hermes/scripts/<name>.py` — cron `script=` takes only the filename (absolute/home-relative paths are refused). Keep a working copy under a project dir for manual runs.
3. Jobs via `cronjob_manage`: `no_agent=true`, `script=<filename>`, `deliver='origin'`, `attach_to_session=true`. Stdout is delivered verbatim (empty stdout sends nothing); a non-zero exit sends an error alert.
4. Hourly snapshots: cron `0 1-23 * * *` (near-24h; 00:00 belongs to the digest). A daytime-only window (e.g. 9-23) reads as "broken" to the user when they check at night — either cover the night or tell them the window explicitly.
5. Midnight digest: cron `0 0 * * *`. The job fires AFTER the date rolled — read YESTERDAY's bucket, rebuild from the JSONL log if missing, then reset it. Compute all four stats (شروع/سقف/کف/آخرین معامله) from the SELL series consistently — user samples show a single series (شروع often equals کف on quiet days). Reset yesterday's bucket ONLY when the day file's stored greg == yesterday; a manual or late summary run must not wipe today's in-progress bucket. When no data exists, header date must be YESTERDAY's, not today's.
6. Digest boundary is the trickiest bug source: test the summary path with synthetic log data reproducing the user's target format end-to-end.
7. DEDUPE identical consecutive snapshots. Keep a `last_sent.json` (greg + buy + sell + saba sell); if the new reading matches it, print NOTHING (empty stdout = nothing delivered). Still log every observation to the JSONL/bucket so the digest sees each hour. Reason: on quiet days (Thu/Fri) values repeat for hours and re-sending identical text makes the user doubt the pipeline (real user reaction: "امکان نداره قیمت از ساعت ۵ صبح تا ۱۰ صبح یکی باشه").
8. Snapshot messages note the hour + source update time (see Key Facts) and include the live sarafi tick when it exists.
9. Dedupe silence looks like failure: a manual `cronjob run` on an unchanged hour returns `Status: silent (empty output)` — that is the dedupe working, not a broken job. For a forced delivery test, post the message directly (or send one snapshot run) instead of wiping `last_sent.json`, so the next scheduled tick stays correctly quiet.

## Dollar card image (iPhone widget style, validated 2026-09-06/07)

- Layout: white rounded square on light-grey canvas; top-right `US Dollar` (bold) / `USD` (lighter); top-left round US flag (circular mask, NOT rectangle); bottom price slightly LEFT of center with change row above it.
- Delivery order the user demands: image FIRST, then the usual text analysis below it. Never text-only when the card was asked for. The platform splits MEDIA:+text cron stdout into photo-then-text automatically.
- Generator: `~/dollar_card.py <sell_now> <sell_prev> <out.png>` (PIL). The hourly cron script renders the card itself and prepends the `MEDIA:` line; a render failure must fall back to text-only, never kill the report.
- Numbers in **Roboto-Bold** (user rejected SF Pro after seeing it rendered); the short `↑`/`↓` change arrow is a unicode glyph in a SMALLER font than the number, not a drawn shape and not a same-size glyph. Price 135px, change 92px.
- Full recipe + flag-drawing code + iteration protocol: `references/dollar-card.md`.

## Pitfalls

- **Never quote a product price from a stale/aggregated page without re-fetching the live listing the same turn.** A56 12/256 was quoted at 44M from a cached aggregator page but the live market was ~124-135M; user called it out («مطمئنی قیمتش انقدره؟») and the wrong number had already been sent. Re-verify from the current source before answering, and when wrong, correct loudly with re-verified numbers.
- **Discontinued products have no shop price — say so and fall back to real listings.** iPhone 13 mini is EOL/unregistered-era: Digikala (all 4 DKPs), Technolife and Torob sellers all show ناموجود with no price. Scrape Divar's category page directly instead: `GET https://divar.ir/s/<city-province>/mobile-phones/apple/apple-iphone-13-mini`, parse `<h2 class="kt-post-card__title">` + following `kt-post-card__description` divs (condition + price text), translate Persian digits, filter ads («اقساط», «خرید داریم») and junk entries (مینی vs نرمال, bait prices like 25M). Present per-condition ranges (کارکرده / در حد نو / نو) rather than fake precision.

- Stripping HTML tags to `|` then regexing pipe-adjacent numbers — alanchand table cells have whitespace/newlines between pipes; strip tags to spaces and window-scan instead.
- Trusting a symbol because it exists in TGJU's aggregated JSON — the feed holds 963 entries including years-dead legacy symbols; check the timestamp first.
- Scheduling the digest at 00:00 and reading "today's" state file — that is the new day; read yesterday. Corollary: resetting the bucket unconditionally after a summary clobbers today's live data when the summary runs late/manually — reset only if the file's greg matches yesterday.
- Writing a large script in one write_file/patch can time out the stream — build it in ~8K-token chunks (write, then append via execute_code).
- Embedding Python source in an execute_code string: a plain `\n` inside an f-string in the written file becomes a REAL newline and breaks syntax — write `\\n` in the chunk string, or write via write_file and fix escapes afterward.
- `snar.ir` (official سنا feed) does not resolve from this network; `tgju.org/profile/*` HTML and `api.tgju.org/v1/*` 404 while `call1.tgju.org/ajax.json` works; bonbast prices are JS-rendered. Retest environment-dependent dead ends before ruling them out permanently.
- The `memory` tool rejects Persian text containing U+200C (ZWNJ) as invisible unicode — write memory entries without it (rephrase to avoid ZWNJ).

## Verification

- [ ] Foreground run of the script prints the exact user-approved format with live values.
- [ ] Unit normalization verified against a known reference (e.g. TGJU rial value vs alanchand toman value for the same market).
- [ ] Digest tested with synthetic yesterday-data; output matches the user's sample exactly.
- [ ] Two consecutive runs with identical values: second prints nothing (dedupe works).
- [ ] Summary run mid-day leaves today's bucket intact.
- [ ] Both cron jobs listed and scheduled with correct cron expressions and `next_run_at` in Tehran time.
- [ ] Persian text in scripts/messages survives; no ZWNJ sent through the memory tool.
