# Dollar card (iPhone widget style) — recipe

Spec from user (2026-09-06, refined through 2026-09-07 iterations): white square, round corners; top-right `US Dollar` bold + `USD` lighter below; top-left round US flag; bottom live price slightly left of center; above price a SHORT `↑`/`↓` arrow + change vs previous.

## Final accepted spec (2026-09-07 — supersedes geometry below where they conflict)
- Numbers in **Roboto-Bold** (`~/fonts/Roboto-Bold.ttf`, from google/roboto `src/hinted/Roboto-Bold.ttf`), NOT SF Heavy — user rejected the final look in SF. Header `US Dollar`/`USD` unchanged.
- Price 135px (user: 175px was too big), Roboto-Bold, fill (20,20,20), center cx = S//2-90, y = S-m-270.
- Change row: number Roboto-Bold 92px, colored (22,163,74) up / (220,38,38) down; center cx_ch = S//2-250, y = pr_y-135.
- **Arrow: unicode `↑`/`↓` glyph rendered SMALLER than the number** — separate `ImageFont.truetype(FONT_RB, 62)` for the glyph vs the 92px digits, drawn at `ch_y+(nh-ah)//2+8` so it optically centers, 14px gap. A drawn shape arrow was rejected; a same-size glyph was called too tall. Verify glyph availability first: `font.getmask('↑').getbbox()` returns non-None in Roboto-Bold here.

## Canvas
- 1080x1080 RGB, background (230,230,230); white rounded_rectangle [60,60,1020,1020] radius 120.
- Top-right texts right-aligned at x = S-m-70; t1 `US Dollar` 72px SF Heavy fill (20,20,20) at y m+80; t2 `USD` 56px fill (150,150,150) at y m+175.
- Flag: 190px circle. Simplified US flag: 13 stripes alternating (178,34,52)/(255,255,255); canton 0.42w x 7/13h fill (60,59,110) with 5x6 white dot grid; circular L-mask ellipse. `img.paste(flag, (m+70, m+80))`.

## Bottom block
- Price: `f"{int(n):,}"` in SF-Pro-Display-Heavy 175px, fill (20,20,20), center cx = S//2-90, y = S-m-270.
- Change: SF Heavy 92px, center cx_ch = S//2-250, y = pr_y-135. Color (22,163,74) up / (220,38,38) down.
- Arrow (drawn, never unicode): box arr_w=72 arr_h=76 shaft_w=26 head_h=34 gap=22; ty = ch_y+(th-arr_h)//2; mid = sx+arr_w//2; sl,sr = mid±shaft_w//2. Up: rectangle [sl,ty+head_h,sr,ty+arr_h] + polygon [(sx,ty+head_h),(sx+arr_w,ty+head_h),(mid,ty)]. Down: mirrored. Text at sx+arr_w+gap.

## Font fetches (verified)
```
cd ~/fonts && curl -sL --max-time 120 -o SF-Pro-Display-Heavy.otf \
  "https://raw.githubusercontent.com/sahibjotsaggu/San-Francisco-Pro-Fonts/master/SF-Pro-Display-Heavy.otf"
curl -sL --max-time 60 -o Roboto-Bold.ttf \
  "https://raw.githubusercontent.com/google/roboto/main/src/hinted/Roboto-Bold.ttf"
python3 -c "from PIL import ImageFont; print(ImageFont.truetype('Roboto-Bold.ttf',100).getname())"
# → ('Roboto', 'Bold')
```

## Cron integration (validated 2026-09-07)
- `fetch_dollar.py` hourly mode renders the card itself: `importlib`-loads `~/dollar_card.py` (see `render_card()` / `prev_sell_for_card()` in `~/.hermes/scripts/fetch_dollar.py`), writes `~/.hermes/dollar/dollar_card.png`, and prepends `MEDIA:<abs path>\n` to the message text it prints. Card render failure falls back to text-only (try/except) so the hourly report never dies.
- Telegram splits `MEDIA:`line+text stdout into TWO messages: photo first, then text. That order is what the user wants — never merge, never text-first.
- Live script: `~/.hermes/scripts/fetch_dollar.py`; keep a mirror copy in `~/.hermes/dollar/`. After any edit: `python3 -m py_compile`, then re-copy the mirror.

## Run
```
python3 ~/dollar_card.py <sell_now> <sell_prev> /storage/emulated/0/Download/dollar_card.png
```
Send with `MEDIA:/storage/emulated/0/Download/dollar_card.png`, analysis text below.

## Iteration protocol
The card took 6 rounds of «نه، فلش/فونت/جاش غلطه». Deliver a sample via `MEDIA:`, let the user attack it, change ONE thing per round, re-send. Never argue the spec — the user's phone is the only reviewer.
