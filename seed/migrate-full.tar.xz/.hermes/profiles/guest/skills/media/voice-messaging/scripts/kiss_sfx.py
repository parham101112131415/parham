"""Synthesize kiss/pop SFX without dependencies (stdlib only)."""
import wave, struct, math, random, sys

def one_kiss(sr=44100, dur=0.22):
    n = int(sr * dur)
    out = []
    for i in range(n):
        t = i / sr
        f = 1800 - 1400 * (i / n)  # sweep down
        env = math.sin(math.pi * i / n) ** 0.7
        tone = math.sin(2 * math.pi * f * t) * env
        click = 0.0
        if i < 200:
            click = (random.random() * 2 - 1) * (1 - i / 200) * 0.8
        v = (tone * 0.9 + click) * 0.9
        out.append(max(-1, min(1, v)))
    return out

def main(path="/tmp/kiss.wav", count=2, gap=0.25, sr=44100):
    silence = [0.0] * int(sr * gap)
    audio = []
    for _ in range(count):
        audio += one_kiss(sr)
        audio += silence
    with wave.open(path, "w") as w:
        w.setnchannels(1)
        w.setsampwidth(2)
        w.setframerate(sr)
        for s in audio:
            w.writeframes(struct.pack("<h", int(s * 32767)))
    print(f"wrote {path}")

if __name__ == "__main__":
    main(sys.argv[1] if len(sys.argv) > 1 else "/tmp/kiss.wav")
