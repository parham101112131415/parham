---
name: voice-messaging
description: "Use when sending voice notes or SFX as voice bubbles."
version: 1.0.0
author: curator
license: MIT
platforms: [linux, macos, windows]
metadata:
  hermes:
    tags: [TTS, Voice, Audio, Telegram, SFX]
---

# Voice Messaging

Send voice notes via TTS or synthesized non-speech SFX, delivered as Telegram voice bubbles.

## Procedure

1. For spoken text: call `text_to_speech` with the requested text first — do not pre-transliterate. For Persian, fully vocalize the text with diacritics (َ ِ ُ) before sending — unvocalized Persian mispronounces.
2. If TTS fails with `No audio was received` on non-Latin script: diagnose once with a short English phrase (e.g. `Mwah, this kiss is for you`) to confirm the provider works, then retry the same content transliterated to Latin characters (Finglish/Romanized) and deliver that, telling the user why.
3. If the request is sound-only with no speech (kiss, pop, beep): do NOT use TTS — prefer a short real recorded SFX download and deliver it directly; extract a direct MP3 URL from a free library page (curl the collection page and grep for `https://...\.mp3`), curl one file down, then transcode to Opus with ffmpeg; use Python stdlib `wave` synthesis (see `scripts/kiss_sfx.py`) only as an offline fallback.
4. Deliver voice on Telegram with both lines in the reply:
   ```
   [[audio_as_voice]]
   MEDIA:/absolute/path/to/file.ogg
   ```
   Any audio format works — non-Opus is transcoded automatically.
5. Keep the chat reply short and in the user's language; note the fallback only when one was used.

## Pitfalls

- When the user explicitly asks for ElevenLabs / a human-like voice and `ELEVENLABS_VOICE_ID` / `ELEVENLABS_MODEL` are configured, honor that provider choice — `ELEVENLABS_API_KEY` may be missing from env but present in the Hermes `.env` file, so grep that file for the key before declaring it absent; only when truly absent, say so plainly and ask the user to resend it rather than silently falling back to the robotic default voice.
- Retry a TTS failure with different arguments (transliteration), not the same text — repeating the same script loops the same provider error.
- Use transliteration as fallback, not first resort — Latin-script retry only after native script returns no audio, so native quality is preserved where supported.
- Never present TTS spoken words as sound-only SFX — TTS always produces speech; pure kiss/pop/click effects require a real recording or waveform synthesis.
- Prefer real recorded SFX over synthesized chirps for human sounds (kiss, smack) — sine-sweep synthesis lacks lip texture and gets rejected as fake.
- Do not switch providers for missing keys or packages mid-task — OpenAI needs an API key and Piper needs `piper-tts` installed; prefer the working default provider plus transliteration over chasing unconfigured providers.
