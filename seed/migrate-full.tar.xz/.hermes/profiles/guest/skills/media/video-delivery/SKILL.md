---
name: video-delivery
description: "Download YouTube videos and deliver them as Telegram files."
version: 1.0.0
author: curator
license: MIT
platforms: [linux, macos, windows]
metadata:
  hermes:
    tags: [video, YouTube, Telegram, yt-dlp, ffmpeg]
    category: media
---

# Video Delivery

Download videos (usually YouTube) and deliver them as Telegram-playable files.

## Procedure

1. Confirm quality first: default to 360p–720p for long videos; offer part-by-part delivery up front when the source likely exceeds chat limits.
2. List formats when the default pick fails, then download an explicit video+audio pair merged to mp4:
```bash
yt-dlp --js-runtimes node --list-formats "URL"
yt-dlp --js-runtimes node -f "134+140-1/135+140-1/best[ext=mp4]/best" \
  --merge-output-format mp4 -o "/tmp/yt_%(id)s.%(ext)s" --no-playlist "URL"
```
3. Check size: Telegram bots cap files at 50 MB. If over, split losslessly into sub-45 MB parts and send each part as its own `MEDIA:` line with a numbered label:
```bash
ffmpeg -y -i in.mp4 -c copy -map 0 -segment_time 172 -f segment -reset_timestamps 1 /tmp/part%02d.mp4
```
4. Run multi-minute downloads/conversions in the background and post short progress updates as the work proceeds — never leave the user silent through a long task.
5. Keep the chat reply short: one `MEDIA:/absolute/path` per part, nothing else heavy.

## Pitfalls

- Verify `yt-dlp` is on PATH before downloading — gateway restarts can wipe it; reinstall with `pip install -q yt-dlp` when `which yt-dlp` finds nothing, then retry the download.
- Instagram reels download with the same yt-dlp pattern (no `--js-runtimes` needed): `yt-dlp --no-playlist -f "best[ext=mp4]/best" --merge-output-format mp4 -o "/tmp/ig_%(id)s.%(ext)s" --no-playlist "REEL_URL"`.
- For long tasks, post a short progress update roughly every 10 seconds — never leave the user silent through a long task.
- Pass `--js-runtimes node` whenever yt-dlp warns about a missing JS runtime — without it, format selection degrades and fails with "Requested format is not available"; never retry a failed `-f` string verbatim, pin an explicit pair from `--list-formats` (audio suffixes like `140-0` vs `140-1` differ per video).
- Re-encoding to shrink (ultrafast preset, high CRF) can come out LARGER than the source — prefer `-c copy` segment splitting for size compliance; re-encode only with efficient presets (veryfast or slower).
- Estimate part counts before a 1080p download of a long video (17 min ≈ 240 MB ≈ 6 parts) and state the wait up front.
