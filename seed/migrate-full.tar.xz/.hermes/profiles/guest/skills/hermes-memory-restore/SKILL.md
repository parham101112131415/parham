---
name: hermes-memory-restore
description: "Use when restoring Hermes state from a backup tgz."
version: 1.0.0
license: MIT
metadata:
  hermes:
    tags: [hermes, memory, backup, restore, skills]
---

# Hermes Memory Restore

Restore agent state from a `hermes-memory-*.tgz` backup without clobbering live config.

## Procedure

1. Inspect before extracting: `tar -tzf <backup>.tgz` to list top-level entries (`memories/`, `SOUL.md`, `skills/...`, `scripts/`, `dollar/`, `jobs-manifest.json`).
2. Extract to a staging dir, never directly into `~/.hermes`: `mkdir -p /tmp/restore && tar -xzf <backup>.tgz -C /tmp/restore`.
3. Diff `SOUL.md` first (`diff -u ~/.hermes/SOUL.md /tmp/restore/SOUL.md`) — it is usually identical; copy only on real difference.
4. Copy `memories/USER.md` and `memories/MEMORY.md` into `~/.hermes/memories/`.
5. Copy each custom skill tree into its existing category path (`~/.hermes/skills/<category>/<name>/`), creating the category dir if needed. Never flatten categories.
6. Restore runtime state the memory text depends on: `scripts/*.py` → `~/.hermes/scripts/`, `dollar/*.json` → `~/.hermes/dollar/`, root-level helpers (e.g. `dollar_card.py`) → `~/`.
7. Re-seed the memory tool from the restored files (user facts → `target=user`, operational facts → `target=memory`) so recall survives even if files are later lost.
8. Verify with `ls` + `diff` and report: what was restored, what was verified, what is left (typically cron jobs from `jobs-manifest.json`).

## Pitfalls

- Preserve live secrets and provider config — never copy backup `.env` or `config.yaml` over the running ones; the live model provider differs and overwriting breaks the session.
- Treat the memory tool store as separate from the files — copying `MEMORY.md` alone does not repopulate it; write the entries explicitly.
- Recreate cron jobs from `jobs-manifest.json` as a separate explicit step — restoring scripts without their schedules leaves hourly/digest pipelines silently dead.
- Keep the backup manifest canonical — `memory_backup.py`'s hardcoded JOBS list generates `jobs-manifest.json` and its ITEMS list decides what gets packed; whenever a cron job or script is added, patched, or removed, update both lists and re-run the script, or the next backup silently drops the change and a future restore loses it.
- Memory-store over-budget recovery — when a memory batch is rejected as over budget, shorten stale entries (dead job IDs, verbose recipes) in the SAME batch as the new add; the budget is checked on the final result, so a lone add that overflows is refused.
