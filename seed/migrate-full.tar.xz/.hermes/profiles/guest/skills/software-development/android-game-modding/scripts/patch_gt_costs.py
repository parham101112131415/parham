"""GT-Club: set every player-money cost to 1. Rerun before EVERY apktool rebuild."""
import UnityPy, sys

BASE = 'work/clone/assets/Bundles/AssetBundles/high/'

def patch_prices(path=BASE + 'pricesconfiguration.high.107'):
    env = UnityPy.load(path)
    n = 0
    for o in env.objects:
        if o.type.name == 'MonoBehaviour':
            d = o.read_typetree()
            for key in ('CarsData', 'UpgradesData', 'LiveriesData'):
                for item in d.get(key, []):
                    pi = item.get('PriceInfo')
                    if pi is not None:
                        if pi.get('Cash', 0) == 0:
                            pi['Cash'] = 1
                        if pi.get('Gold', 0) == 0:
                            pi['Gold'] = 1
                        n += 1
            o.save_typetree(d)
    with open(path, 'wb') as f:
        f.write(env.file.save())
    print(f'prices: {n} items -> 1')

def patch_currencies(path=BASE + 'currenciesconfiguration.high.109'):
    env = UnityPy.load(path)
    n = 0
    for o in env.objects:
        if o.type.name == 'MonoBehaviour':
            d = o.read_typetree()
            fuel = d.get('Fuel', {})
            if fuel.get('GoldToFillTank', 0) > 1:
                fuel['GoldToFillTank'] = 1; n += 1
            for k, v in fuel.items():
                if k.endswith('Cost') and isinstance(v, int) and v > 1:
                    fuel[k] = 1; n += 1
            for cat, opts in d.get('Consumables', {}).items():
                if isinstance(opts, dict):
                    for vals in opts.values():
                        if isinstance(vals, dict):
                            for ck in ('GoldCost', 'CashCost'):
                                if vals.get(ck, 0) > 1:
                                    vals[ck] = 1; n += 1
            for vals in d.get('Gold', {}).get('Mechanics', {}).values():
                if isinstance(vals, dict) and vals.get('Cost', 0) > 1:
                    vals['Cost'] = 1; n += 1
            o.save_typetree(d)
    with open(path, 'wb') as f:
        f.write(env.file.save())
    print(f'currencies: {n} costs -> 1')

if __name__ == '__main__':
    patch_prices(sys.argv[1] if len(sys.argv) > 1 else BASE + 'pricesconfiguration.high.107')
    patch_currencies(sys.argv[2] if len(sys.argv) > 2 else BASE + 'currenciesconfiguration.high.109')
