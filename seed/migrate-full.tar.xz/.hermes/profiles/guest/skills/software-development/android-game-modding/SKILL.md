---
name: android-game-modding
description: 'Mod Android APK games for personal use.'
version: 1.0.0
---

# Android Game Modding (personal use)

Client-side mods for Android games the user owns, for their own device only.
Never distribute modded APKs, never attack live servers, never mod values
that give an advantage over other players in multiplayer.

## Boundaries (hard)

- If the target value is server-authoritative (wallet balance, server-computed
  rewards, zero balance rejected by server validation), say so plainly and
  stop. A local patch cannot change server state.
- GameGuardian RAM edits are NOT proof an APK patch exists: GG changes live
  memory, a mod must change a file on disk at a stable address.
- Personal use only. Do not help publish or share modded APKs.

## Workflow

1. **Identify the engine.** Unzip-list the APK:
   - `lib/arm64-v8a/libil2cpp.so` + `assets/bin/Data/Managed/Metadata/global-metadata.dat`
     = Unity IL2CPP. Method names live in metadata, code in the `.so` (no
     stable file addresses for C# methods — static patching needs an anchor).
   - `assets/Bundles/AssetBundles/` = Addressables bundles (per-car files,
     `*configuration*` files). Game balance often lives here as data.
   - `resource.car` = Corona/Solar2D (Lua). Currency there is usually server-side.
2. **Prefer data mods over code patches.** A config bundle with prices/costs
   edited down is more robust than NOP-ing checks. Prefer setting nonzero
   prices to **1, not 0**: some games hide the buy button when price == 0,
   while price 1 keeps the button and still passes server validation that
   would reject forged balances.
3. **Edit Unity bundles with UnityPy** (`pip install UnityPy`):
   `read_typetree()` -> mutate -> `save_typetree()` -> persist with
   `env.file.save(packer='original')` returning bytes (see pitfalls).
4. **Rebuild by zip-entry replace**: copy the APK, swap only the changed
   entry via `zipfile` preserving `compress_type`, then `apksigner sign`
   and `apksigner verify`. Fresh keystore per game is fine (fresh install).
5. **Verify before delivery**: re-extract the changed file from the SIGNED apk
   and re-check the values; report counts, not narratives.

## Pitfalls

- Price 0 can hide the buy button entirely (observed in GT-Club:
  zeroed prices -> no purchase option rendered). Use 1 for any price that
  was originally > 0; leave originally-free (0/0) entries alone.
- When true automation needs a code patch you cannot anchor (e.g. auto-shift
  in a stripped IL2CPP binary), look for a DATA equivalent first: timing
  windows / difficulty bands in config bundles (GT-Club:
  `CarGearChangeLightRangesData.GoodGearChangeBand` 300 -> 3000 +
  `PerfectGearChangeBandFraction` 0.5 -> 1.0 widens the perfect-shift zone
  ~10x). Same effect for the user, zero native patching.
- apktool rebuild can fail on aapt2 with `resource 'drawable/$avd_...' has
  invalid entry name` (appcompat animated-vector files). Fix: rename
  `$avd_` -> `fix_avd_` in the filenames, in referencing drawables, and in
  `res/values/public.xml`, then rebuild.
- `env.save(out_path=...)` fails when the environment was loaded from a
  plain path (`FileNotFoundError` on the output dir) — use
  `env.file.save(packer='original')` and write the returned bytes yourself.
- apksigner password flags take a SPACE: `--ks-pass pass:SECRET`, not
  `--ks-pass:SECRET` ("Unsupported option" error otherwise). Same for
  `--key-pass` and `--ks-key-alias`.
- `zipalign` may be absent in Termux — apksigner works without it.
- Lost keystore password = forced signature change: a fresh keystore means the
  user MUST uninstall the old clone before installing (Android rejects
  same-package/different-cert updates). Tell them upfront, one line.
- Re-patch data bundles before EVERY rebuild from the decoded tree — apktool
  rebuilds carry whatever is currently in `clone/assets` (GT-Club prices
  silently reverted to 0, hiding the buy button again).
- Check tier/level gates too (e.g. `TierN_UnlockLevel`); they may already be 0.
- Warn on online games: local price edits may still be rejected by server-side
  checks at purchase time. Ship as "try it and report the exact error".
- Ship the LITERAL request, never a 'better' automation on top: twice the user had to stop a substitution — first the screenshot/PixelCopy eye ("don't take pictures, change the game code"), then auto-click/auto-shift when they asked only for the tutorial shift prompt to always appear ("it doesn't need to auto-click, just do what I said"). When they name the deliverable, build exactly that; offer the fancier version as a separate next step, never merged in silently.
- Do NOT widen gameplay timing bands as a "helper": GT-Club green-shift band
  widen 10x caused wheelspin/slowdown (user: hitting green early = tire slip).
  Assist UI and shift logic are coupled — revert data widening, use a real
  auto-shift hook instead.
- Read the game's own code BEFORE writing a native hook: `strings -n 3` on
  `global-metadata.dat` plus neighbor lines (+-2) maps class membership
  with no dumper (names appear in declaration order). GT-Club map:
  `GearLightsDisplay` fields `currentRevs/redlineRpm/idleRpm`, methods
  `GreenLightOn/shouldDisplay/areWeRacing`; `IngameLessonGearUp` fields
  `hasBroughtUpDialog/m_gear/m_lastDialogAt`, methods
  `ShowInTutorialDialog/HideTutorialDialog/StateUpdate`; `get_IsInTopGear` /
  `get_CurrentGear` live on `GearBoxData`, NOT `GearBox` — binding them on
  the wrong class fails silently at runtime (no error, just never fires).
- Tutorial prompts are usually one-shot gated (`hasBroughtUpDialog` /
  `_hasBroughtUpDialog`): the object often still exists in later scenes,
  just never fires again. Re-arm by zeroing the bool via
  `il2cpp_class_get_field_from_name` + `il2cpp_field_get_offset` (~every 2s),
  letting the game's own `StateUpdate` show its real dialog + pause.
  No clicks needed.
- Ship the LITERAL gate only unless the user explicitly asks for more: re-arm `hasBroughtUpDialog` so the game's OWN `StateUpdate` shows its real dialog. NO auto-click/tap, NO `timeScale` slow-mo, NO always-on banner as substitutes — all three were explicitly rejected after being built unasked ("just do what I said", "I didn't ask you to slow down", "it doesn't need to auto-click"). Offer fancier automation as a separate next step, never merged in silently.
- IF the user explicitly asks for shift reaction time (and only then): `Time.set_timeScale(0.2)` slow-mo on green over full `0.0` (at 0 revs freeze so green never clears and the game stays stuck). Always resume when green clears OR after a ~2.5s timeout, and skip when `get_IsInTopGear` is true. Pass float params to `il2cpp_runtime_invoke` as pointer-to-value (`void* args[1] = {&v}`).
- `Boot.boot` called from `UnityPlayerActivity.onCreate` runs BEFORE
  `setContentView` — a view added directly in `boot()` gets wiped. Post via
  `Handler(Looper.getMainLooper()).post` a `Runnable` (e.g. `Boot$Hint
  implements Runnable`) with a `findViewWithTag` guard + `postDelayed`
  re-add loop. And confirm the user wants an always-on banner before
  building one — it may be rejected as noise.

## Frida gadget (no-root code hook)

- Use only when a data mod cannot achieve it (e.g. true auto-shift on green).
- Version matters: gadget 16.6.6 crashed on Android 16 at launch; 17.5.0
  worked. If instant-crash on launch, upgrade gadget first.
- Embed: `lib/arm64-v8a/libfrida-gadget.so` (STORED, not deflated) +
  `lib/arm64-v8a/libfrida-gadget.config.so` containing
  `{"interaction":{"type":"script","path":"/data/user/0/<clone_pkg>/files/gadget.js"}}`
  (also STORED) + `assets/gadget.js` + `com/mahsa/Boot.smali` called from
  `UnityPlayerActivity.onCreate` that copies `gadget.js` to files dir then
  `System.loadLibrary("frida-gadget")`.
- Repack rule: any `lib/*.so` entry must be `ZIP_STORED` in the final APK.
  Python `zipfile` repack defaults to deflated — set STORED explicitly or
  the lib/config may not extract and the script never runs.
- Stage diagnostics with toasts, do not guess: `M-boot` (Boot ran) ->
  `M-gadget OK/FAIL` (so loaded) -> `M-f js:YES/<bytes>|NO` + `M-f cfg:YES|NO`
  (files present, checked via Handler.postDelayed ~25s) -> `M-js NATIVE-YES|NO`
  (native marker file written from JS via fopen/fputs, proves JS executed
  even if the Java bridge is broken). `M-gadget OK + NATIVE-NO` with a VALID
  STORED config and confirmed-present js/cfg files can persist indefinitely
  (observed on GT-Club: 2204-byte js, cfg YES, still no execution) — do NOT
  burn more cycles on config variants; escalate to the in-app smali agent
  (`references/gt-club-autoshift-inapp.md`) or external ADB automation.
- Next rung `M-log`: have Boot$Check run `logcat -d` (own-process logs need
  no permission) and toast the LAST line matching the gadget tag. Smali
  try/catch syntax is `.catch Ljava/lang/Exception; {:trylog .. :logshow}
  :catchlog`. Two lessons: (1) the only matching line may be nativeloader's
  `Loading libfrida-gadget.so...` — that is a load receipt, NOT an error;
  (2) take the last match, logcat buffers hold stale lines from prior runs.
- Liveness rung when script autoload never fires (`M-gadget OK + NATIVE-NO`):
  switch config to listen mode
  `{"interaction":{"type":"listen","address":"127.0.0.1","port":27042,"on_load":"resume"}}`,
  rebuild, then `adb forward tcp:27042 tcp:27042` + socket test
  (`timeout 3 bash -c 'cat < /dev/null > /dev/tcp/127.0.0.1/27042' && echo
  OPEN || echo CLOSED`). OPEN proves the gadget is alive AND reading its
  config — so the failure is isolated to script-file loading, not gadget
  init. (Stale forwards give `cannot bind listener: Address already in use`;
  harmless — the forward already exists.)
- Alternate execution proof when the native file marker never appears: toast
  straight from JS via the Java bridge — `Java.use("android.app.ActivityThread")`
  -> `currentApplication().getApplicationContext()` -> call the public static
  `Boot.t(ctx, "M-js JAVA-YES")`, with a `setTimeout` retry (`JAVA-LATE`)
  for races where the bridge is not ready at script load. File-marker NO +
  Java-toast YES = marker I/O problem, not a dead script engine.
- Do NOT plan around a Termux frida client: neither `pip install frida` nor
  `npm i frida` builds on-device. Both fall back to source builds needing
  Frida's dated toolchain bundle from build.frida.re (missing/unfetchable),
  and prebuild-install mis-resolves the asset version. All gadget-side logic
  must therefore be self-contained in `gadget.js` (autoload or listen with
  an external dumb trigger), never a local `frida -H` session.

## On-device ADB automation (no root, no PC)

- When a code hook cannot be anchored (stripped IL2CPP) and gadget JS will
  not execute, automate from outside: Termux `adb` paired to the phone
  itself via Settings -> Developer options -> Wireless debugging
  (`adb pair <ip>:<pairport>` with the pairing code, then
  `adb connect <ip>:<adbport>`). Then `input tap` + screen reading.
- Latency rule: `adb exec-out screencap -p` costs ~0.55-0.8s per shot
  (measured) — unusable for sub-second reaction windows (e.g. shift flash).
  Use live H264 instead: `adb exec-out screenrecord --size 480x360
  --bit-rate 800000 --output-format=h264 --time-limit 0 -` piped to
  `ffmpeg -f h264 -use_wallclock_as_timestamps 1 -i - -f rawvideo -pix_fmt
  rgb24 -` (~24-28 fps, sub-100ms reaction). Without
  `-use_wallclock_as_timestamps 1` ffmpeg decodes ZERO frames from the live
  pipe (file-decode of the same bytes works — misleading).
- Binary rule: `adb shell` mangles binary stdout (newline conversion);
  always use `adb exec-out` for screencap/screenrecord bytes.
- Never leave an unread PIPE: ffmpeg stderr must be DEVNULL (or drained by
  a thread) or the pipe buffer fills and the pipeline stalls. With
  `-v error` the dims preamble is suppressed — hardcode the `--size` you
  requested (verify once with ffprobe) instead of parsing stderr.
- Blind UI mapping (when the vision model is down): PIL+numpy 16x8 grid of
  green%/white% per cell renders the layout as readable text; `np.nonzero`
  centroid of a color cluster gives tap points as fractions (resolution-
  independent). Validate the detector BOTH ways: all zones must FIRE on the
  reference "active" screenshot, and `--test` on a neutral screen must read ~0.
- Delivery for non-technical users: after handing over a mod/script, give
  SHORT numbered steps in plain colloquial Persian, no jargon, no process
  narration. Match reply length to the ask.

## Native il2cpp self-introspection probe (no root, no frida)

- When the binary is stripped AND gadget JS will not execute (`M-gadget OK +
  NATIVE-NO` indefinitely), enumerate live C# classes from inside the process:
  a constructor-attributed `.so` (`System.loadLibrary` from Boot.smali) that
  dlsyms `il2cpp_class_for_each` + friends from `libil2cpp.so` and logcats
  class/method/field dumps. Tutorial screens are enough (dump ~10s after
  start, no race needed). Build on-device with
  `aarch64-linux-android-clang -shared -fPIC -O2 -o libX.so file.c -llog`
  (needs `#include <stdio.h>`). Full recipe + GT-Club findings:
  `references/gt-club-il2cpp-probe.md`.
- Key finding pattern: look for the game's own event wiring (GT-Club:
  `GearLightsDisplay::GearChangeLogic_FireGearChangeUpEvent` — the HUD
  subscribes to the shift event, which is the anchor for a real auto-shift
  hook via `il2cpp_runtime_invoke` of `GearShiftUp` on the PLAYER's box only).

## Reference recipes

- `references/gt-club-il2cpp-probe.md` — no-root native probe enumerating live
  il2cpp classes/methods/fields via exported API + GT-Club shift-logic map.
- `references/gt-club-prices-mod.md` — zeroing all car/upgrade/livery prices
  in GT-Club via its prices-configuration bundle (worked locally, server
  acceptance unverified).
- `references/gt-club-clone-apk.md` — clone APK that installs alongside the
  original: apktool decode, package rename, `$avd_` aapt2 fix, rebuild,
  sign, zip-replace data bundles.
- `references/gt-club-frida-gadget.md` — no-root Frida gadget embed +
  staged toasts (M-boot/M-gadget/M-f/M-js) and version/STORED rules.
- `references/gt-club-autoshift-adb.md` — on-device auto-shift: wireless
  self-pair, screencap-latency finding, live screenrecord+ffmpeg pipeline,
  blind grid-map UI analysis, zone detector validation.
- `references/gt-club-autoshift-inapp.md` — self-contained in-app agent in
  smali (PixelCopy eye + synthetic MotionEvent tap), incl. detector tuning
  from a race screenshot and smali assembler rules (lit8/lit16, /range).
- Delivery for non-technical users: after handing over a mod/script, give
  SHORT numbered steps in plain colloquial Persian, no jargon, no process
  narration. Match reply length to the ask. Diagnostic questions back to the
  user must be single-choice and terse — they answer in short codes
  user), so ask "which number/word did you see" not "describe".
  Stay in the established persona and address terms for the whole session —
  going dry/technical mid-task reads as a behavior change and draws a
  complaint. (Here: assistant is Mahsa, user is Parham; affectionate
  colloquial Persian throughout, never lecture.)
  In-game solutions beat external tooling for this user: an adb tapper that
  needs a terminal during the race will be rejected even if it works.
