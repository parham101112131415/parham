# GT-Club: native libil2cpp self-introspection probe (no root, no frida)

When the binary is stripped (no C# names in libil2cpp.so) and the frida-gadget
script engine will not execute (`M-gadget OK + NATIVE-NO` indefinitely), enumerate
the live classes from inside the process with il2cpp's own exported API.

## Why it works

`libil2cpp.so` exports the full introspection set (verified via `nm -D`):
`il2cpp_class_for_each`, `class_get_name/namespace/image/methods/fields`,
`class_get_field_from_name`, `class_get_method_from_name`, `method_get_name`,
`method_get_return_type`, `method_get_param_count`, `method_get_param`,
`field_get_name/type/offset`, `type_get_name`, plus the invocation set for the
follow-up hook: `runtime_invoke`, `object_unbox`, `class_get_type`,
`type_get_object`, `array_length`, `array_object_header_size`, `string_new`,
`value_box`, `object_get_class`, `domain_get`, `free`.

## Probe .so recipe

- C file with `__attribute__((constructor))` spawning a pthread that:
  1. `dlopen("libil2cpp.so")` in a retry loop (up to ~120s),
  2. `dlsym`s the functions above,
  3. `sleep(8-10)` so il2cpp finishes registering classes after Unity start,
  4. `il2cpp_class_for_each(report, 0)`; `report` filters by name substring
     and logs `CLASS ns.name img=X` + up to N `M name(params):ret` +
     `F +offset name:type` lines via `__android_log_print` (tag `MAHSA`).
- Matching is case-insensitive substring on class name (v1: green/gear/shift/
  tacho/rpm/redline/paddle/clutch/transmission/gearbox; v2: exact shortlist
  incl. gearchangelogic, gearlightsdisplay, greenlightindicator, carphysics,
  rpmui, rpmregion, shiftpaddle, optimalgearchange, carinput, racecar, engine).
- Build on-device: `aarch64-linux-android-clang -shared -fPIC -O2 -o
  libmahsa_auto.so mahsa_auto.c -llog` (8.5K). Needs `#include <stdio.h>`
  for snprintf or clang errors on implicit declaration.
- Ship: copy to `clone/lib/arm64-v8a/`, load from Boot.smali with
  `System.loadLibrary("mahsa_auto")` + toast `M-native OK/FAIL`.
- Read: `adb logcat -v brief -d | grep MAHSA`. Class dump fires ~10s after
  game start — the tutorial/first screens are enough, no race needed.

## What the dump revealed (GT-Club, Assembly-CSharp.dll, empty namespace)

- `GearBox`: `GearShiftUp`, `GearShiftDown`, `get_CurrentGear`, `get_IsInTopGear`,
  `get_IsGearShifting`, `OrderedUpdate`, `UpdateClutch`, `GetNextGear`.
- `GearChangeLogic`: `GearUp`, `GearDown`, `CalculateOptimalShiftPoint`,
  `FireRPMRegionEvents`, `add/remove_FireGearChangeUpEvent`,
  `get/set_CarPhysics`.
- `GearLightsDisplay`: `GreenLightOn`, `Update`, `UpdateNumLightsOn`,
  `SetLightStates`, and crucially `GearChangeLogic_FireGearChangeUpEvent` —
  the HUD SUBSCRIBES to the logic's shift event. That event is the game's own
  "time to shift" signal and the anchor for a real auto-shift hook.
- `GreenLightIndicator`: `UpdateIndicator`; `RpmUI`: `updateUI`; `Tacho`:
  `set_currentRevs`; `ShiftPaddleAnimator`: `ActivateGearUp`.
- Hook plan (not yet built): poll or intercept at the event point and
  `il2cpp_runtime_invoke` `GearShiftUp` on the player's GearBox instance
  (find via `FindObjectsOfType`/cached `this` — AI cars have their own
  boxes, never shift all instances).

## v3/v4 findings (signatures, field offsets, dialog-only hook)

- `GearLightsDisplay.GreenLightOn():System.Boolean`, 0 args — a pure getter,
  safe to `runtime_invoke` from any thread. `GetlighImage():bool` also exists.
- `GearLightsDisplay` fields (offsets stable in this build): `+88
  currentRevs:System.Single`, `+92 redlineRpm:System.Single`, `+96
  idleRpm`, `+128 m_greenLightIndicator`. Direct float reads at +88/+92
  are MORE robust than invoking the getter — use `revs >= red * 0.96` as
  the green-zone trigger (same band the tutorial dialog uses).
- `Tacho` fields: `+72 minimumGoodRevs`, `+76 minimumPerfectRevs`, `+80
  maximumPerfectRevs`, `+88 maximumGoodRevs`, `+92 minimumBadRevs`.
- Lesson classes: `IngameLessonGearUp` + `IngameLessonGearUpAfterFirst` with
  `ShowInTutorialDialog()` (0-arg). Invoking it on
  `FindObjectsOfTypeAll` instances shows the REAL tutorial shift prompt with
  no shifting and no taps — the literal deliverable when the user asks for
  the prompt itself. Fire once per green entry + ~500ms cooldown; log
  `DLG!` vs `DLG-miss (no lesson obj)` so absence of instances is visible.
- `array_object_header_size` takes 1 arg (pass the element klass); header is
  32 bytes on arm64, stride 8. Always `il2cpp_thread_attach(domain)` before
  `runtime_invoke` from a private pthread.

## Companion notes

- Keystore loss: if the original keystore password is gone, a fresh keystore
  changes the signature — the user MUST uninstall the old clone first.
  Always note keystore alias at creation; never store the password in notes.
- Prices re-patch on every rebuild from the `clone/` tree: the bundle at
  `assets/Bundles/AssetBundles/high/pricesconfiguration.high.107` reverts to
  zeros — rerun the prices script before EACH `apktool b` (16227 items -> 1;
  CarsData 288 / UpgradesData 4830 / LiveriesData 11109).
