# GT-Club auto-shift via on-device ADB (no root, no PC)

Reaction automation when Frida gadget JS will not execute (M-gadget OK +
M-js NATIVE-NO) and no static data equivalent exists.

## Setup (user does once, ~6 numbered steps in plain Persian)

1. Settings -> About phone -> tap Build number 7x.
2. Developer options -> Wireless debugging ON.
3. "Pair device with pairing code" -> note IP, pair port, 6-digit code.
4. Termux: `adb pair <ip>:<pairport>`, enter code.
5. Termux: `adb connect <ip>:<adbport>` (port on the Wireless debugging screen).
6. `adb devices` must list one device.

Working set from this session: `~/gt/autoshift/` (`setup_adb.sh`, `shot.sh`,
`autoshift.py` slow version, `autoshift_fast.py` live version).

## Calibration without vision

- `shot.sh`: `adb exec-out screencap -p > /storage/.../Download/gt_race.png`
  while the car is moving; user sends the pic.
- Grid map: 16 cols x 8 rows, print green% and white% per cell
  (green = G>150 & G>R+40 & G>B+40). Clusters reveal signal zones.
- Tap point: centroid (`np.nonzero` mean) of the fixed-UI cluster (here the
  glowing `+` paddle: fx=0.829, fy=0.794 on 2400x1080 landscape).
- GT-Club zones (fractions): top "now" indicator (0.55,0.35,0.65,0.47,
  min 0.02), gauge glow (0.38,0.75,0.62,1.00, min 0.03), paddle glow backup
  (0.78,0.70,0.88,0.89, min 0.03). Cooldown 0.6-0.8s between taps.
- Validate: detector FIRES on all zones in the reference active shot AND
  reads ~0 on a neutral screen (`--test`) before shipping.

## Live pipeline (the part that made it work)

```
adb exec-out screenrecord --size 480x360 --bit-rate 800000 \
  --output-format=h264 --time-limit 0 - \
| ffmpeg -v error -f h264 -use_wallclock_as_timestamps 1 -i - \
  -f rawvideo -pix_fmt rgb24 - \
| python3 autoshift_fast.py   # reads W*H*3 bytes/frame, zone check, input tap
```

Measured: screencap 0.55-0.8s/shot (misses brief flashes, taps land late
and look random); H264 stream ~24-28fps. Tap via
`adb shell input tap <x> <y>` with fractional coords x live size.

## Failure modes seen

- ffmpeg live-decodes 0 frames without `-use_wallclock_as_timestamps 1`
  (file-decode of identical bytes works — do not trust file tests).
- `adb shell` corrupts binary stdout; `exec-out` is mandatory for media bytes.
- Unread stderr PIPE stalls the pipeline; use DEVNULL + hardcoded dims.
- Random taps + misses = stale frames (latency), not bad thresholds.
  Fix the capture path first, tune thresholds second.
