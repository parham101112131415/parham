# GT-Club Frida gadget recon (no-root auto-shift path)

## Layout (clone pkg `com.kingkodestudio.z2hmod`)
- `lib/arm64-v8a/libfrida-gadget.so` — gadget 17.5.0 (24MB), STORED
- `lib/arm64-v8a/libfrida-gadget.config.so` — STORED, content:
  `{"interaction":{"type":"script","path":"/data/user/0/com.kingkodestudio.z2hmod/files/gadget.js"}}`
- `assets/gadget.js` — recon v1 (read-only): native alive-marker first
  (fopen/fputs `/files/js_native.txt` via libc, no Java bridge), then
  `Java.perform` toast `Mahsa gadget ON`, il2cpp `SHIFT>>` discovery.
- `com/mahsa/Boot.smali` — called from `UnityPlayerActivity.onCreate`:
  copy asset `gadget.js` -> files dir, `System.loadLibrary("frida-gadget")`,
  toast `M-boot` / `M-copy FAIL` / `M-gadget OK|FAIL`, schedule
  `Boot$Check` via `Handler.postDelayed(25s)`.
- `com/mahsa/Boot$Check.smali` — toasts `M-f js:YES <len>|NO`,
  `M-f cfg:YES|NO` (nativeLibraryDir + `/libfrida-gadget.config.so`),
  `M-js NATIVE-YES|NO` (js_native.txt exists).

## Decision table
- `M-boot` missing = onCreate patch not hit (check smali hook).
- `M-gadget FAIL` = so not extracted / wrong arch (check STORED + arm64).
- `OK + M-f js:NO` = asset copy failed (check assets/gadget.js in APK).
- `OK + M-f cfg:NO` = config not extracted (check STORED, filename
  `libfrida-gadget.config.so`).
- `OK + js:YES + cfg:YES + NATIVE-NO` = gadget ignores config/path
  (version mismatch or path unreadable) — upgrade gadget, verify path.
- `NATIVE-YES but no ON/SHIFT` = JS runs, Java bridge broken — fix toasts,
  keep native logging.

## Version note
- 16.6.6: instant crash on Android 16. 17.5.0: loads (M-gadget OK).
- Always `node --check assets/gadget.js` before build.
- After apktool build, python-repack bundles/prices then force
  `ZIP_STORED` for `lib/*.so`, apksigner sign + verify, check staged
  dex contains `M-f js:YES` marker before delivery.
