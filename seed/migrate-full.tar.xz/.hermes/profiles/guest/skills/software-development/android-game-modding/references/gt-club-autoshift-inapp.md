# In-app auto-shift agent (no root, no Frida, no ADB during play)

When gadget JS will not execute (`M-gadget OK` but markers never appear even
with valid STORED config) and external tapping is too slow/inaccurate, inject
a self-contained eye+tap loop in smali. Proven pattern (GT-Club clone):

## Architecture

4 smali classes under `com/mahsa/`, called once from `Boot.boot(ctx)`:

- `Auto.start(Context)` — `check-cast` ctx to Activity (try/catch +
  `M-auto FAIL` toast), gate `Build$VERSION.SDK_INT >= 0x1a` (PixelCopy
  Window overloads need API 26+), create main-looper Handler, toast
  `M-auto ON`, `postDelayed(new Auto$Loop(), 3000)`.
- `Auto$Loop implements Runnable` — `run()` calls `Auto.tick()`, reposts
  itself with `postDelayed(this, 90)`.
- `Auto.tick()` — builds a small `Bitmap` + `Rect` (zone as % of
  `DisplayMetrics.widthPixels/heightPixels`, integer math `W*68/100`), then
  `PixelCopy.request(Window, Rect, Bitmap, new Auto$Copy(bmp), handler)`.
  Copy is async; failures arrive as non-zero result, never exceptions.
- `Auto$Copy implements PixelCopy$OnPixelCopyFinishedListener` —
  `onPixelCopyFinished(I)`: if `p1 == 0` call `Auto.maybeShift(bmp)`.
- `Auto.maybeShift(Bitmap)` — cooldown gate
  (`uptimeMillis - lastShift >= 450ms`), sample every 4th pixel via
  `getPixel`, count lit-green, trigger `doTap()` if per-mille >= threshold.
- `Auto$Tap implements Runnable` — run on UI thread via
  `Activity.runOnUiThread`: `MotionEvent.obtain(down,event,DOWN,x,y,0)` +
  `decorView.dispatchTouchEvent` + same for UP + `recycle()`.

## Detector tuning (from a real race screenshot)

- Find the lit indicator with PIL: downscale, mask `g>140 && g>r+40 &&
  g>b+40`, flood-fill blobs, take bounding boxes as zone fractions.
- Strict in-app rule used: `g>=0xAA && r<=0x6E && b<=0x82 && (g-r)>=0x46`,
  sampled step 4, fire threshold 8 per mille of zone pixels.
- Tap point = blob center as % of screen (GT-Club `+`: 78% x, 82% y).
- If user reports early/late/misfire, only these constants move: zone rect,
  color bounds, per-mille threshold, cooldown. One rebuild per tuning round.

## Smali assembler rules (apktool/smali hard errors)

- `mul-int vA, vB, vC` / `div-int` take THREE registers — with a literal use
  `mul-int/lit8`, `div-int/lit8` (value must fit signed 8-bit), or
  `mul-int/lit16` (e.g. x1000 = `0x3e8`). Error looks like
  `mismatched input '0x44' expecting REGISTER`.
- `invoke-static {…}` (format35c) holds MAX 5 registers. 6+ needs
  `invoke-static/range {v1 .. v6}` with CONTIGUOUS registers in exact
  parameter order (wides first: J occupies v1+v2, then I, F, F, I).
  Error looks like `mismatched tree node: UP expecting I_CATCHES`.
- Wide (J) locals consume two slots — size `.locals` accordingly.
- New classes go straight into the apktool tree
  (`smali_classesN/com/mahsa/…`); `apktool b` assembles them, no d8 needed.
  No `javac`/`android.jar` required anywhere in this flow.
