# GT-Club prices mod (session recipe)

Game: GT-Club 1.15.22 (Unity IL2CPP 2022.3.52f1, online via Nakama/Xsolla).
Goal: all cars unlocked, all upgrades free — personal-use mod.

## Key finding

Balance is data, not code: `assets/Bundles/AssetBundles/high/pricesconfiguration.high.107`
(UnityFS bundle) holds a `PricesConfiguration` MonoBehaviour with typetree fields:

- `CarsData`: 288 entries, `{Name, PriceInfo: {Cash, Gold}}`
- `UpgradesData`: 4830 entries, same shape
- `LiveriesData`: 11109 entries, same shape

`carsconfiguration.high.106` holds `CarsConfiguration` with
`Tier1..5_UnlockLevel` all already 0 — no level gate to clear.

Car purchase goes through the client price table, so zeroing prices is the
right lever (server rejects forged balances but a 0-price purchase needs no
balance). Server-side re-validation at purchase time still possible —
acceptance unverified, user testing pending.

## Procedure (verified)

Set prices to **1, not 0**: price 0 hides the buy button entirely (user:
"I zeroed it again, the buy option doesn't appear — I told you make them
1"). Only touch entries that cost the player; leave originally-free alone.
Companion script: `scripts/patch_gt_costs.py` (prices bundle + currency
costs below, rerun before EVERY rebuild).

```python
import UnityPy
src = 'work/assets/Bundles/AssetBundles/high/pricesconfiguration.high.107'
env = UnityPy.load(src)
for obj in env.objects:
    if obj.type.name == 'MonoBehaviour' and getattr(obj.read(), 'm_Name', '') == 'PricesConfiguration':
        tt = obj.read_typetree()
        for lst in ['CarsData', 'UpgradesData', 'LiveriesData']:
            for e in tt[lst]:
                e['PriceInfo']['Cash'] = 0
                e['PriceInfo']['Gold'] = 0
        obj.save_typetree(tt)
        break
data = env.file.save(packer='original')  # NOT env.save(out_path=...) — see pitfalls
open('work/pricesconfiguration.high.107', 'wb').write(data)
```

Result: 16227 entries set to 1 (got: 288 / 4830 / 11109).

## Beyond the prices bundle (same session)

- `currenciesconfiguration.high.109`: 33 real-money sinks -> 1:
  `Fuel.GoldToFillTank` (20), all `Fuel.*Cost` race fuel costs (incl.
  `BossBattleCost` 2), every `Consumables.*.{GoldCost,CashCost}` (nitro/tyre/
  engine/agent, cash 2800-3500 ones included), all `Gold.Mechanics.*.Cost`
  (30-80). Skip `Deliveries.SpeedUpSecondsPerGold` (exchange RATE — lowering
  it raises the gold cost) and delivery times (gameplay timing, not money).
- `carepackagesconfiguration`: its Gold/Cash values are level REWARDS
  (earnings), not costs — do NOT touch (account-safety + server risk).
- `bundleiapsconfiguration` / `iapconfiguration`: real-money IAP,
  Google-billed and server-verified — skip entirely.

Rebuild: `zipfile` entry-replace of that single path in a copy of the APK
(4301 entries, preserve `compress_type`), then:

```
keytool -genkeypair -keystore gt.keystore -alias gt ...  # one-time
apksigner sign --ks gt.keystore --ks-pass pass:PASS --key-pass pass:PASS --ks-key-alias gt --out SIGNED.apk UNSIGNED.apk
apksigner verify SIGNED.apk  # silent == OK
```

Verify: re-extract bundle from SIGNED apk, reload typetree, assert
`Cash+Gold == 0` over all three lists (got: 288 / 4830 / 11109, total 0).
Delivered as `GT-Club_1.15.22_مهسا_ماشین_رایگان.apk`.
