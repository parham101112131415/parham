# Clone APK (GT-Club 1.15.22) — install alongside original

## Why
User did not want to uninstall the original. A clone needs a different
`package` so Android treats it as a separate app.

## Package discovery (no aapt in Termux)
Decode `AndroidManifest.xml` (binary) as utf-16-le and regex for
`(com|ir|net|org)\.[\w]+(\.[\w]+)+`. GT-Club: `com.kingkodestudio.z2h`.
Clone: `com.kingkodestudio.z2hmod`.

## Steps (verified end-to-end)
1. Start from the modded APK (data bundles already replaced via zip-swap).
2. `apktool d mod.apk -o clone -f` (decode; ~180 MB Unity APK, takes minutes).
3. `sed -i 's/com\.kingkodestudio\.z2h/com.kingkodestudio.z2hmod/g'
   clone/AndroidManifest.xml` — renames package + all provider authorities
   (35 occurrences; avoids INSTALL_FAILED_CONFLICTING_PROVIDER).
   Verify: only `z2hmod` remains in the manifest.
4. Optional label so the launcher shows it apart:
   `clone/res/values/strings.xml`: `<string name="app_name">GT-Club Mahsa</string>`.
5. Rebuild `apktool b clone -o clone.apk`. If aapt2 fails with
   `resource 'drawable/$avd_hide_password__N' has invalid entry name`:
   `cd clone/res/drawable && rename '$avd_' -> 'fix_avd_'` on the 6 files,
   then `sed -i 's/\$avd_/fix_avd_/g'` on `avd_hide_password.xml`,
   `avd_show_password.xml`, and `res/values/public.xml`. Rebuild again.
6. Swap data bundles into the built APK via `zipfile` (preserving
   `compress_type`), then `apksigner sign --ks <ks> --ks-pass pass:...`
   `--key-pass pass:... --ks-key-alias <alias>` and `apksigner verify`.
7. Verify from the SIGNED apk: re-extract manifest (only new package) and
   bundles (UnityPy re-check of edited values).

## Notes
- Same keystore/key across iterations lets the clone update in place.
- Clone keeps the original's server account system; warn about guest
  accounts losing progress only if the user uninstalls something (they don't
  need to here).
