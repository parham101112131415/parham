---
name: hermes-watchdogs
description: "Use for watchdog cron jobs and DM pairing approvals."
version: 1.0.0
license: MIT
metadata:
  hermes:
    tags: [hermes, cron, watchdog, pairing, telegram, no-agent]
---

# Hermes Watchdogs & Pairing

Recurring no-agent cron jobs that stay silent unless something new happened, and admitting new chat users via DM pairing without touching the dashboard.

## Watchdog script contract

1. One stdlib-only script under `~/.hermes/scripts/<name>.py` — cron `script=` takes only the filename, never a path.
2. The script keeps its own state file (notified request IDs, last-sent values); each tick prints ONLY new events and nothing otherwise — empty stdout delivers nothing, which is the silent-tick behavior, not a failure.
3. Prune state entries that aged out (expired codes, approved users) so the state file never grows without bound.
4. Schedule via `cronjob_manage`: `no_agent=true`, `script=<filename>`, `deliver='origin'`, `attach_to_session=true`.
5. Prove the contract with a synthetic event before scheduling: run against empty state (expect silence), inject one fake event (expect exactly one notice), run again (expect silence), then delete the fake data and the state file.

## DM pairing approvals

1. Strangers DMing the bot receive a one-time pairing code (1-hour expiry) — but ONLY while unauthorized-DM behavior is pairing. Any configured allowlist env (e.g. `TELEGRAM_ALLOWED_USERS`) flips the gateway default to silently ignoring strangers, so no code ever arrives; fix with `hermes config set platforms.<platform>.unauthorized_dm_behavior pair` followed by `hermes gateway restart`. The allowlist itself stays configured so the owner is always admitted.
2. A watchdog tick posts newly-seen pending requests (platform, user ID/name, request ID) to the home chat.
3. When the owner relays approval in chat, run the CLI over terminal: `hermes pairing approve <platform> <request-id-or-code>` — either the request ID from the notice or the code the stranger relayed works. Approval appends the user to the configured allowlist and takes effect on their next message; no restart, no dashboard.

## Faster-than-cron notices

Cron's floor is one tick per minute. For second-scale latency, run a background daemon that loops every few seconds: capture the watchdog script's stdout, and when non-empty deliver it directly (e.g. Telegram Bot API `sendMessage` to the owner's chat ID) instead of relying on cron delivery. The daemon touches a heartbeat file each loop; the cron twin exits silently on a fresh heartbeat (env-gated early return), so it acts purely as a dead-daemon backup and the same event is never announced twice. A machine reboot kills the daemon while cron survives — keep both, and record the daemon's restart command in memory.

## Pitfalls

- Resolve the pairing store the way the gateway does: a populated legacy `~/.hermes/pairing/` wins, otherwise `~/.hermes/platforms/pairing/` — an empty legacy dir never counts, and reading the wrong dir makes pending requests silently invisible.
- Filter pending entries by `created_at` against the 1-hour TTL, or the notice goes out for an already-dead code.
- Never enable allow-all admission on a terminal-capable bot — pairing keeps admission in the owner's hands while strangers still get a reply (their code) instead of silence.
- A gateway restart kills the turn that issued it — after reconnect, report recovery and never re-issue the restart or replay the interrupted commands.
- Admitted users inherit the global persona and memory — chat sessions are per-user, but there is one shared USER.md/MEMORY.md, so scope owner-only tone and private facts by owner ID in standing memory or every new user gets greeted as the owner.
