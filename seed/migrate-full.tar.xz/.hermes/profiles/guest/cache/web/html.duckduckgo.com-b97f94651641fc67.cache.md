Unfortunately, bots use DuckDuckGo too.

Please complete the following challenge to confirm this search was made by a human.

Select all squares containing a duck:

![ ](https://html.duckduckgo.com/assets/anomaly/images/challenge/e2d99a9d0de3af04b25030dd92dd87de.jpg)

![ ](https://html.duckduckgo.com/assets/anomaly/images/challenge/d00e62f93da14d23e5aa76f46040ff07.jpg)

![ ](https://html.duckduckgo.com/assets/anomaly/images/challenge/20e9ac858806321167f5fe115d58890c.jpg)

![ ](https://html.duckduckgo.com/assets/anomaly/images/challenge/6d735ea13f6a47a58ebc0eca71549fa3.jpg)

![ ](https://html.duckduckgo.com/assets/anomaly/images/challenge/82fd90a42c4d2b0240a2d2f5fc3b9c53.jpg)

![ ](https://html.duckduckgo.com/assets/anomaly/images/challenge/10b707df866e8e33cfbabeee6b8e1401.jpg)

![ ](https://html.duckduckgo.com/assets/anomaly/images/challenge/e37d21a0e79cdee762d69b69eaa37bfb.jpg)

![ ](https://html.duckduckgo.com/assets/anomaly/images/challenge/220855b597cf8fb58695fcdd3138bd15.jpg)

![ ](https://html.duckduckgo.com/assets/anomaly/images/challenge/fcc80e34af33b761b56272288eeff3e5.jpg)

Submit

Images not loading?

Please email the following code to:

error-lite+ed82@duckduckgo.com

Code: ed82

![](https://duckduckgo.com/t/tqadb?3252790&s=lite&gk=d4cd0dabcf4caa22ad92fab40844c786&sc=1&o=7kVWHEN1%2BkaMod%2BFiF0LW74FjlcZdrZ9YKtFiingaX15ULHyNPMgMEoy6eLIbAf0%0A&i=-1&e=0&c=dadb&r=use&p=e2d99a9d0de3af04b25030dd92dd87de-d00e62f93da14d23e5aa76f46040ff07-20e9ac858806321167f5fe115d58890c-6d735ea13f6a47a58ebc0eca71549fa3-82fd90a42c4d2b0240a2d2f5fc3b9c53-10b707df866e8e33cfbabeee6b8e1401-e37d21a0e79cdee762d69b69eaa37bfb-220855b597cf8fb58695fcdd3138bd15-fcc80e34af33b761b56272288eeff3e5&iadb=0&cc=sre)