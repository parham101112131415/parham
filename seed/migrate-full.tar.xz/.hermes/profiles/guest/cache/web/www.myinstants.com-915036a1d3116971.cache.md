# Kissing Sound

![Favorites](/media/images/icons/favorite-red.svg) **8,660 users** favorited this sound button

112,792 views