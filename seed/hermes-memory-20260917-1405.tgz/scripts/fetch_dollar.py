#!/usr/bin/env python3
"""Hourly USD/Tehran snapshot (now) + midnight digest (summary). Stdlib only."""
import json
import os
import re
import sys
import urllib.request
from datetime import datetime, timedelta, timezone

TEH = timezone(timedelta(hours=3, minutes=30))
_HH = os.environ.get("HERMES_HOME") or os.path.expanduser("~")
DOLLAR_DIR = os.path.join(_HH, "dollar")
LOG_PATH = os.path.join(DOLLAR_DIR, "dollar_log.jsonl")
DAY_PATH = os.path.join(DOLLAR_DIR, "dollar_day.json")
LAST_PATH = os.path.join(DOLLAR_DIR, "last_sent.json")
CARD_PATH = os.path.join(DOLLAR_DIR, "dollar_card.png")
def _find_card_gen():
    for p in (
        os.path.expanduser("~/dollar_card.py"),
        os.path.join(DOLLAR_DIR, "dollar_card.py"),
        os.path.expanduser("~/dollar/dollar_card.py"),
        "/opt/data/dollar/dollar_card.py",
        "/opt/data/dollar_card.py",
    ):
        if os.path.exists(p):
            return p
    return os.path.expanduser("~/dollar_card.py")
CARD_GEN = _find_card_gen()

FA_TABLE = str.maketrans(
    "۰۱۲۳۴۵۶۷۸۹٠١٢٣٤٥٦٧٨٩", "01234567890123456789")


def fa2en(s):
    return str(s).translate(FA_TABLE)


def parse_num(s):
    s = fa2en(s).replace(",", "").replace(".", "").strip()
    s = re.sub(r"[^\d]", "", s)
    return int(s) if s else None


def fmt(n):
    return "{:,}".format(int(n))


WEEKDAYS = ["دوشنبه", "سه\u200cشنبه", "چهارشنبه", "پنجشنبه",
            "جمعه", "شنبه", "یکشنبه"]


def gregorian_to_jalali(gy, gm, gd):
    g_d_m = [0, 31, 59, 90, 120, 151, 181, 212, 243, 304, 334]
    if gy > 1600:
        jy = 979
        gy -= 1600
    else:
        jy = 0
        gy -= 621
    gy2 = gy + 1 if gm > 2 else gy
    days = (365 * gy + (gy2 + 3) // 4 - (gy2 + 99) // 100
            + (gy2 + 399) // 400 - 80 + gd + g_d_m[gm - 1])
    jy += 33 * (days // 12053)
    days %= 12053
    jy += 4 * (days // 1461)
    days %= 1461
    if days > 365:
        jy += (days - 1) // 365
        days = (days - 1) % 365
    if days < 186:
        jm = 1 + days // 31
        jd = 1 + days % 31
    else:
        jm = 7 + (days - 186) // 30
        jd = 1 + (days - 186) % 30
    return jy, jm, jd


def fetch_json(url, timeout=25):
    req = urllib.request.Request(url, headers={"User-Agent": "Mozilla/5.0"})
    with urllib.request.urlopen(req, timeout=timeout) as r:
        return json.load(r)


def fetch_tgju():
    d = fetch_json("https://call1.tgju.org/ajax.json")
    cur = d.get("current", {})
    out = {}
    rl = cur.get("price_dollar_rl") or {}
    out["tgju_last"] = parse_num(rl.get("p", "")) // 10 if rl.get("p") else None
    out["tgju_high"] = parse_num(rl.get("h", "")) // 10 if rl.get("h") else None
    out["tgju_low"] = parse_num(rl.get("l", "")) // 10 if rl.get("l") else None
    dt = cur.get("price_dollar_dt") or {}
    out["dt_last"] = parse_num(dt.get("p", "")) // 10 if dt.get("p") else None
    saba = cur.get("sabaexchange_usd_sell") or {}
    out["saba_sell"] = parse_num(saba.get("p", "")) // 10 if saba.get("p") else None
    out["saba_t"] = fa2en(str(saba.get("t_en", "") or "")).strip() or None
    return out


def fetch_alanchand():
    req = urllib.request.Request("https://alanchand.com/currencies-price",
                                 headers={"User-Agent": "Mozilla/5.0"})
    html = urllib.request.urlopen(req, timeout=25).read().decode("utf-8", "ignore")
    txt = re.sub(r"<[^>]+>", " ", html)
    i = txt.find("دلار آمریکا")
    if i < 0:
        raise RuntimeError("alanchand: USD row not found")
    nums = re.findall(r"[۰-۹0-9][۰-۹0-9,\.]*", txt[i:i + 300])[:2]
    if len(nums) < 2:
        raise RuntimeError("alanchand: buy/sell parse failed")
    m = re.search(r"آخرین بروز رسانی\s*:\s*([۰-۹0-9:\s]+)", txt)
    upd = fa2en(m.group(1)).strip() if m else None
    return {"buy": parse_num(nums[0]), "sell": parse_num(nums[1]),
            "alan_update": upd}


def load_json(path, default):
    try:
        with open(path, encoding="utf-8") as f:
            return json.load(f)
    except (OSError, ValueError):
        return default


def save_json(path, obj):
    tmp = path + ".tmp"
    with open(tmp, "w", encoding="utf-8") as f:
        json.dump(obj, f, ensure_ascii=False)
    os.replace(tmp, path)


def midnight_sell_for_card(bucket, greg_today):
    """مرجع ساعت ۱۲ شب: اولین معامله‌ی امروز. اگر امروز هنوز معامله‌ای ندارد، آخرین دیروز از لاگ."""
    entries = bucket.get("entries", []) if bucket.get("greg") == greg_today else []
    if entries and entries[0].get("sell"):
        return entries[0].get("sell")
    # fallback: آخرین sell دیروز از لاگ
    try:
        from datetime import datetime as _dt
        y = (_dt.strptime(greg_today, "%Y-%m-%d") - timedelta(days=1)).strftime("%Y-%m-%d")
        last_y = None
        with open(LOG_PATH, encoding="utf-8") as f:
            for line in f:
                try:
                    e = json.loads(line)
                except ValueError:
                    continue
                if e.get("greg") == y and e.get("sell"):
                    last_y = e.get("sell")
        if last_y:
            return last_y
    except Exception:
        pass
    return None


def render_card(sell_now, sell_prev):
    import importlib.util
    spec = importlib.util.spec_from_file_location("dollar_card", CARD_GEN)
    mod = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(mod)
    mod.render(sell_now, sell_prev, CARD_PATH)


def cmd_now():
    os.makedirs(DOLLAR_DIR, exist_ok=True)
    now_teh = datetime.now(TEH)
    greg = now_teh.strftime("%Y-%m-%d")
    jy, jm, jd = gregorian_to_jalali(now_teh.year, now_teh.month, now_teh.day)
    wd = WEEKDAYS[now_teh.weekday()]
    hm = now_teh.strftime("%H:%M")

    alan = fetch_alanchand()
    tgju = fetch_tgju()
    buy, sell = alan["buy"], alan["sell"]
    if buy is None or sell is None:
        raise RuntimeError("alanchand returned empty buy/sell")

    obs = {"ts": datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ"),
           "greg": greg, "jalali": "%04d-%02d-%02d" % (jy, jm, jd),
           "weekday": wd, "hm": hm, "buy": buy, "sell": sell,
           "tgju_last": tgju["tgju_last"], "tgju_high": tgju["tgju_high"],
           "tgju_low": tgju["tgju_low"], "dt_last": tgju.get("dt_last"),
           "saba_sell": tgju["saba_sell"],
           "saba_t": tgju["saba_t"], "alan_update": alan["alan_update"]}
    with open(LOG_PATH, "a", encoding="utf-8") as f:
        f.write(json.dumps(obs, ensure_ascii=False) + "\n")

    bucket = load_json(DAY_PATH, {})
    if bucket.get("greg") != greg:
        bucket = {"greg": greg, "entries": []}
    bucket["entries"].append(obs)
    save_json(DAY_PATH, bucket)

    last = load_json(LAST_PATH, {})
    save_json(LAST_PATH, {"greg": greg, "buy": buy, "sell": sell,
                          "saba_sell": tgju["saba_sell"]})

    lines = ["دلار فردایی تهران ⏳ %s خــرید🔵" % fmt(buy),
             "دلار فردایی تهران ⏳ %s فروش🔴" % fmt(sell),
             "",
             "📍 تهران | %s %s" % (wd, hm)]
    if tgju["tgju_last"]:
        lines.append("TGJU — last %s | high %s | low %s"
                     % (fmt(tgju["tgju_last"]), fmt(tgju["tgju_high"]),
                        fmt(tgju["tgju_low"])))
    if tgju["saba_sell"]:
        saba_line = "Sarafi — sell %s" % fmt(tgju["saba_sell"])
        if tgju["saba_t"]:
            saba_line += " (%s)" % tgju["saba_t"]
        lines.append(saba_line)
    legs = {"آلان": sell, "tgju": tgju["tgju_last"], "dt": tgju.get("dt_last")}
    legs = {k: v for k, v in legs.items() if v}
    if len(legs) >= 2:
        lo, hi = min(legs.values()), max(legs.values())
        if lo and (hi - lo) * 100 // lo >= 2:
            detail = "، ".join("%s %s" % (k, fmt(v)) for k, v in legs.items())
            lines.append("⚠️ اختلاف منابع: " + detail)
    text = "\n".join(lines)

    try:
        midnight = midnight_sell_for_card(bucket, greg)
        render_card(sell, midnight if midnight else sell)
        sys.stdout.write("MEDIA:" + CARD_PATH + "\n" + text)
    except Exception:
        sys.stdout.write(text)


def cmd_summary():
    os.makedirs(DOLLAR_DIR, exist_ok=True)
    now_teh = datetime.now(TEH)
    yest = (now_teh - timedelta(days=1)).date()
    ygreg = yest.strftime("%Y-%m-%d")
    jy, jm, jd = gregorian_to_jalali(yest.year, yest.month, yest.day)
    wd = WEEKDAYS[yest.weekday()]
    header = "📌 پایان معاملات\n\n🗓 %s | %04d.%02d.%02d" % (wd, jy, jm, jd)

    bucket = load_json(DAY_PATH, {})
    sells = []
    if bucket.get("greg") == ygreg:
        sells = [e.get("sell") for e in bucket.get("entries", [])
                 if e.get("sell")]
    if not sells:
        try:
            with open(LOG_PATH, encoding="utf-8") as f:
                for line in f:
                    line = line.strip()
                    if not line:
                        continue
                    try:
                        e = json.loads(line)
                    except ValueError:
                        continue
                    if e.get("greg") == ygreg and e.get("sell"):
                        sells.append(e["sell"])
        except OSError:
            pass

    if bucket.get("greg") == ygreg:
        save_json(DAY_PATH, {"greg": now_teh.strftime("%Y-%m-%d"),
                             "entries": []})

    if not sells:
        sys.stdout.write(header + "\n📭 معامله\u200cای ثبت نشد")
        return
    # --- محاسبه تغییر نسبت به دیروز (آخرین دیروز vs آخرین پریروز) ---
    prev_last = None
    try:
        from datetime import datetime as _dt2
        yp = (_dt2.strptime(ygreg, "%Y-%m-%d") - timedelta(days=1)).strftime("%Y-%m-%d")
        with open(LOG_PATH, encoding="utf-8") as f:
            for line in f:
                try:
                    e = json.loads(line)
                except ValueError:
                    continue
                if e.get("greg") == yp and e.get("sell"):
                    prev_last = e.get("sell")
    except Exception:
        prev_last = None
    delta_line = ""
    if prev_last and sells[-1]:
        diff = sells[-1] - prev_last
        if diff == 0:
            delta_line = "\n📊 نسبت به دیروز: بدون تغییر"
        else:
            arrow = "📈" if diff > 0 else "📉"
            word = "افزایش" if diff > 0 else "کاهش"
            pct = abs(diff) * 100 / prev_last if prev_last else 0
            delta_line = "\n%s نسبت به دیروز: %s %s تومان (%.2f%%) %s" % (arrow, fmt(abs(diff)), word, pct, "🔺" if diff>0 else "🔻")
    sys.stdout.write(header
                     + "\n✅ شروع معاملات: %s" % fmt(sells[0])
                     + "\n📈 سقف معاملات: %s" % fmt(max(sells))
                     + "\n📉 کف معاملات: %s" % fmt(min(sells))
                     + "\n⏳ آخرین معامله: %s" % fmt(sells[-1])
                     + delta_line)


if __name__ == "__main__":
    mode = sys.argv[1] if len(sys.argv) > 1 else "now"
    if mode == "now":
        cmd_now()
    elif mode == "summary":
        cmd_summary()
    else:
        sys.exit("usage: fetch_dollar.py [now|summary]")
