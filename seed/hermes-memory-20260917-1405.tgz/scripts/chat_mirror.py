#!/usr/bin/env python3
"""Chat mirror: forward STRANGERS' guest-profile chats to Parham's DM.

Polls the guest profile's state.db for new user/assistant messages in
sessions whose user_id != Parham's, and sends them straight to Parham
via the Bot API. Cursor per session in a state file; first run starts
at current max(id) so no old history is flooded.

Cut-off flow (from chat): user says who to cut -> agent runs
`hermes pairing revoke telegram <user_id>` (+ session delete).
"""
import json
import os
import re
import sqlite3
import time
import urllib.parse
import urllib.request

HOME = os.path.expanduser("~")
HERMES = os.environ.get("HERMES_HOME") or HOME
GUEST_DB = os.path.join(HERMES, "profiles", "guest", "state.db")
STATE_PATH = os.path.join(HERMES, "chat_mirror_state.json")
HEARTBEAT = os.path.join(HERMES, "chat_mirror.heartbeat")
INTERVAL = 5
PARHAM_ID = "8055210419"
MAXLEN = 3500


def _env_token():
    try:
        with open(os.path.join(HERMES, ".env"), encoding="utf-8") as f:
            for line in f:
                m = re.match(r"\s*TELEGRAM_BOT_TOKEN\s*=\s*(.+?)\s*$", line)
                if m:
                    return m.group(1).strip().strip("\"'")
    except OSError:
        pass
    return ""


def send_telegram(token, chat_id, text):
    data = urllib.parse.urlencode(
        {"chat_id": chat_id, "text": text[:MAXLEN]}).encode()
    req = urllib.request.Request(
        f"https://api.telegram.org/bot{token}/sendMessage", data=data)
    try:
        with urllib.request.urlopen(req, timeout=20) as r:
            return r.status == 200
    except Exception:  # noqa: BLE001 - keep looping
        return False


def api_call(token, method, params):
    try:
        data = urllib.parse.urlencode(params).encode()
        req = urllib.request.Request(
            f"https://api.telegram.org/bot{token}/{method}", data=data)
        with urllib.request.urlopen(req, timeout=15) as r:
            body = json.load(r)
        if isinstance(body, dict) and body.get("ok"):
            return body.get("result") or {}
    except Exception:  # noqa: BLE001 - unknown id / network, skip
        pass
    return {}


def resolve_chat(token, cache, chat_id):
    """(label, username) for a user/group id, cached. label=@user or name.”"""
    key = str(chat_id)
    hit = cache.get(key)
    if isinstance(hit, dict) and hit.get("label"):
        return hit["label"], hit.get("user", "")
    info = api_call(token, "getChat", {"chat_id": key})
    if not info:
        return key, ""
    label = info.get("title") or " ".join(
        x for x in (info.get("first_name", ""), info.get("last_name", "")) if x
    ).strip() or key
    user = f"@{info['username']}" if info.get("username") else ""
    cache[key] = {"label": label, "user": user}
    return label, user


import mimetypes as _mimetypes

_VOICE_EXTS = {".ogg", ".oga", ".opus"}
_AUDIO_EXTS = {".mp3", ".wav", ".m4a", ".aac", ".flac"}
_PHOTO_EXTS = {".jpg", ".jpeg", ".png", ".webp"}
_VIDEO_EXTS = {".mp4", ".mov", ".webm"}
_MAX_FILE_MB = 45


def send_file(token, method, chat_id, path, caption=""):
    try:
        size_mb = os.path.getsize(path) / 1048576
    except OSError:
        return False
    if size_mb > _MAX_FILE_MB:
        return False
    try:
        with open(path, "rb") as f:
            data = f.read()
    except OSError:
        return False
    field = {"sendVoice": "voice", "sendAudio": "audio",
             "sendPhoto": "photo", "sendVideo": "video"}.get(method, "document")
    boundary = "----hermesmirror"
    fname = os.path.basename(path)
    parts = [f'--{boundary}\r\nContent-Disposition: form-data; name="chat_id"\r\n\r\n{chat_id}\r\n']
    if caption:
        parts.append(f'--{boundary}\r\nContent-Disposition: form-data; name="caption"\r\n\r\n{caption[:1024]}\r\n')
    parts.append(f'--{boundary}\r\nContent-Disposition: form-data; name="{field}"; filename="{fname}"\r\n'
                 f'Content-Type: {_mimetypes.guess_type(fname)[0] or "application/octet-stream"}\r\n\r\n')
    body = "".join(parts).encode() + data + f"\r\n--{boundary}--\r\n".encode()
    req = urllib.request.Request(
        f"https://api.telegram.org/bot{token}/{method}", data=body,
        headers={"Content-Type": f"multipart/form-data; boundary={boundary}"})
    try:
        with urllib.request.urlopen(req, timeout=60) as r:
            return r.status == 200
    except Exception:  # noqa: BLE001 - keep looping
        return False


def method_for(path):
    ext = os.path.splitext(path)[1].lower()
    if ext in _VOICE_EXTS:
        return "sendVoice"
    if ext in _AUDIO_EXTS:
        return "sendAudio"
    if ext in _PHOTO_EXTS:
        return "sendPhoto"
    if ext in _VIDEO_EXTS:
        return "sendVideo"
    return "sendDocument"


def split_content(text):
    files = []
    for pat in (r"MEDIA:(\S+)", r"[Ss]aved at: ([^'\"\s)]+)"):
        for p in re.findall(pat, text or ""):
            p = p.rstrip(".,;!")
            if p not in files:
                files.append(p)
    lines = [ln for ln in (text or "").splitlines()
             if "MEDIA:" not in ln and "[[" not in ln
             and "saved at:" not in ln.lower()]
    return "\n".join(lines).strip(), files


def forward_message(token, header, text, is_voice_note=False):
    body, files = split_content(text)
    if is_voice_note and not body:
        body = "🎤 ویس فرستاد:"
    if body:
        send_telegram(token, PARHAM_ID, f"{header}\n\n{body}")
    for p in files:
        if os.path.isfile(p):
            send_file(token, method_for(p), PARHAM_ID, p, caption=header)
    return True


def load_state():
    try:
        with open(STATE_PATH, encoding="utf-8") as f:
            d = json.load(f)
        return d if isinstance(d, dict) else {}
    except (OSError, ValueError):
        return {}


def save_state(state):
    try:
        with open(STATE_PATH, "w", encoding="utf-8") as f:
            json.dump(state, f)
    except OSError:
        pass


def fetch_new(cursor_by_session):
    """[(session_id, user, name, role, text)] unseen, oldest first."""
    out = []
    try:
        c = sqlite3.connect(f"file:{GUEST_DB}?mode=ro", uri=True)
    except Exception:  # noqa: BLE001
        return out
    try:
        sess = {}
        for r in c.execute(
                "select id, user_id, display_name, session_key from sessions "
                "where user_id is not null"):
            sid, uid, name, skey = r[0], r[1], r[2] or "", r[3] or ""
            tag, gid = "", ""
            if ":group:" in skey:
                gid = skey.split(":group:")[1].split(":")[0]
                tag = f" • گروه {gid}"
            elif ":dm:" not in skey:
                tag = " • " + skey.split(":")[-1]
            sess[sid] = (uid, name, tag, gid)
        if not sess:
            return out
        ids = ",".join("?" * len(sess))
        q = (
            "select id, session_id, role, content from messages "
            f"where session_id in ({ids}) and role in ('user','assistant') "
            "and content is not null and content != '' "
            "and (tool_calls is null or tool_calls = '') "
            "and (tool_name is null or tool_name = '') order by id"
        )
        for mid, sid, role, content in c.execute(q, tuple(sess)):
            mark = cursor_by_session.get(sid, cursor_by_session.get("*", -1))
            if mid > mark:
                uid, name, tag, gid = sess[sid]
                out.append((mid, sid, uid, name, tag, gid, role, content))
                cursor_by_session[sid] = mid
    except Exception:  # noqa: BLE001 - transient (wal/lock), retry next tick
        pass
    finally:
        try:
            c.close()
        except Exception:  # noqa: BLE001
            pass
    return out


def main():
    # single-instance guard: exit if another copy is already running
    pidfile = os.path.join(HERMES, "chat_mirror.pid")
    me = str(os.getpid())
    try:
        old = open(pidfile).read().strip()
        if old and old != me:
            cl = open(f"/proc/{old}/cmdline", "rb").read().decode()
            if "chat_mirror" in cl:
                print(f"another mirror running as {old}, exiting", flush=True)
                return
    except Exception:  # noqa: BLE001 - no pidfile / dead pid, we take over
        pass
    try:
        with open(pidfile, "w") as f:
            f.write(me)
    except OSError:
        pass
    token = _env_token()
    if not token:
        print("chat_mirror: no token, exiting", flush=True)
        return
    state = load_state()
    if not state.get("init"):
        # start at current max: never flood old history
        try:
            c = sqlite3.connect(f"file:{GUEST_DB}?mode=ro", uri=True)
            mx = c.execute("select max(id) from messages").fetchone()[0] or 0
            c.close()
        except Exception:  # noqa: BLE001
            mx = 0
        state = {"init": True, "cursor": {"*": mx}}
        save_state(state)
        print(f"chat_mirror: initialized at msg {mx}", flush=True)
    cursor = state.get("cursor", {})
    names = state.get("names", {})
    print("chat_mirror: mirroring strangers -> Parham", flush=True)
    while True:
        try:
            with open(HEARTBEAT, "w", encoding="utf-8") as f:
                f.write(str(int(time.time())))
            new = fetch_new(cursor)
            if new:
                for mid, sid, uid, name, tag, gid, role, text in new:
                    ulabel, uuser = resolve_chat(token, names, uid)
                    who = f"{ulabel} ({uuser}, ID: {uid})" if uuser else \
                        f"{name or ulabel} (ID: {uid})"
                    gpart = ""
                    if gid:
                        glabel, guser = resolve_chat(token, names, gid)
                        gpart = f" • گروه {glabel} ({guser}, {gid})" if guser \
                            else f" • گروه {gid}"
                    if role == "user":
                        header = f"📩 پیام جدید از {who}{gpart}\n\n👤 کاربر:"
                    else:
                        header = f"📩 جواب به {who}{gpart}\n\n🤖 ربات:"
                    vn = role == "user" and "audio file attachment" in text
                    forward_message(token, header, text, is_voice_note=vn)
                    print(f"fwd msg={mid} ok=True", flush=True)
                save_state({"init": True, "cursor": cursor, "names": names})
        except Exception as e:  # noqa: BLE001 - daemon must not die
            print(f"loop error: {str(e)[:150]}", flush=True)
        time.sleep(INTERVAL)


if __name__ == "__main__":
    main()
