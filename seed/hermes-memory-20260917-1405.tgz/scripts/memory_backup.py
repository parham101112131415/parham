#!/usr/bin/env python3
"""Daily full backup: memory + SOUL + custom skills + scripts + dollar state + jobs manifest. Prints MEDIA: line for cron delivery. No secrets (.env excluded)."""
import hashlib
import json
import os
import sqlite3
import tarfile
from datetime import datetime, timedelta, timezone

TEH = timezone(timedelta(hours=3, minutes=30))
HOME = os.path.expanduser("~")
HERMES = os.environ.get("HERMES_HOME") or HOME
BACKUP_DIR = os.path.join(HERMES, "backups")
os.makedirs(BACKUP_DIR, exist_ok=True)

now_teh = datetime.now(TEH)
stamp = now_teh.strftime("%Y%m%d-%H%M")
out = os.path.join(BACKUP_DIR, f"hermes-memory-{stamp}.tgz")

JOBS = [
    {"name": "dollar-hourly", "schedule": "30 0-19,21,22,23 * * *", "script": "fetch_dollar.py",
     "no_agent": True, "deliver": "origin", "attach_to_session": True,
     "prompt": "Hourly Tehran free-market dollar snapshot. The script ~/.hermes/scripts/fetch_dollar.py (default mode now) fetches alanchand buy/sell and TGJU rates, logs to ~/.hermes/dollar/, dedupes identical hours by printing nothing, renders the dollar card PNG and prints MEDIA: line plus message text. Stdout is delivered verbatim; empty stdout sends nothing."},
    {"name": "dollar-midnight", "schedule": "30 20 * * *", "script": "dollar_summary.py",
     "no_agent": True, "deliver": "origin", "attach_to_session": True,
     "prompt": "Midnight Tehran dollar digest. The script ~/.hermes/scripts/dollar_summary.py runs fetch_dollar.py in summary mode: reads YESTERDAY's bucket from ~/.hermes/dollar/dollar_day.json, falls back to rebuilding from dollar_log.jsonl, prints the digest, and resets yesterday's bucket only if its greg matches yesterday. Stdout is delivered verbatim."},
    {"name": "memory-backup", "schedule": "35 */2 * * *", "script": "memory_backup.py",
     "no_agent": True, "deliver": "origin", "attach_to_session": True,
     "prompt": "Daily memory backup. The script ~/.hermes/scripts/memory_backup.py packs memory, skills, scripts and dollar state into a timestamped tgz under ~/.hermes/backups/ (keeps last 7) and prints a MEDIA: line plus caption. Stdout is delivered verbatim so the backup file arrives in chat."},
    {"name": "pairing-watch", "schedule": "* * * * *", "script": "pairing_watch.py",
     "no_agent": True, "deliver": "origin", "attach_to_session": True,
     "prompt": "Pairing watchdog. The script ~/.hermes/scripts/pairing_watch.py reads the gateway pairing store, remembers notified request_ids, and prints a message ONLY for newly-seen pending DM pairing requests (or newly-approved users). Stdout is delivered verbatim; empty stdout sends nothing."},
]

manifest_path = os.path.join(BACKUP_DIR, "jobs-manifest.json")
with open(manifest_path, "w") as f:
    json.dump(JOBS, f, ensure_ascii=False, indent=2)

RESTORE_TXT = """Restore trigger: user sends this tgz and says «مهسا برگرد» (or asks to restore from backup).
1. Extract tgz to a temp dir.
2. Copy memories/USER.md + memories/MEMORY.md -> ~/.hermes/memories/ (also load each § section into the memory tool).
3. Copy SOUL.md -> ~/.hermes/SOUL.md (only if user confirms overwrite).
4. Copy skills/* -> ~/.hermes/skills/ (merge, keep existing).
5. Copy scripts/* -> ~/.hermes/scripts/ ; dollar/* -> ~/.hermes/dollar/ ; dollar_card.py + fonts/ -> home dir.
6. state/main-state.db + state/guest-state.db are session snapshots (restore only with gateway stopped, ask first).
7. .env + config.yaml: restore ONLY on a new machine / explicit user order (they hold secrets + model config).
8. Recreate cron jobs from jobs-manifest.json (no_agent, deliver=origin, attach) unless they already exist.
9. Verify: py_compile scripts, test-run memory_backup.py (2nd run must be silent), report what was restored.
"""
restore_path = os.path.join(BACKUP_DIR, "RESTORE.md")
with open(restore_path, "w") as f:
    f.write(RESTORE_TXT)

ITEMS = [
    ("memories/USER.md", "memories/USER.md"),
    ("memories/MEMORY.md", "memories/MEMORY.md"),
    ("SOUL.md", "SOUL.md"),
    ("skills/productivity/iran-fx-rates", "skills/productivity/iran-fx-rates"),
    ("skills/software-development/android-game-modding", "skills/software-development/android-game-modding"),
    ("scripts/fetch_dollar.py", "scripts/fetch_dollar.py"),
    ("scripts/dollar_summary.py", "scripts/dollar_summary.py"),
    ("scripts/memory_backup.py", "scripts/memory_backup.py"),
    ("scripts/pairing_watch.py", "scripts/pairing_watch.py"),
    ("scripts/pairing_daemon.py", "scripts/pairing_daemon.py"),
    ("scripts/chat_mirror.py", "scripts/chat_mirror.py"),
    ("dollar/dollar_day.json", "dollar/dollar_day.json"),
    ("dollar/last_sent.json", "dollar/last_sent.json"),
    ("platforms/pairing", "platforms/pairing"),
    ("channel_directory.json", "channel_directory.json"),
    ("chat_mirror_state.json", "chat_mirror_state.json"),
    ("pairing_watch_state.json", "pairing_watch_state.json"),
    ("jobs-manifest.json", "jobs-manifest.json"),
    ("RESTORE.md", "RESTORE.md"),
    (".env", ".env"),
    ("config.yaml", "config.yaml"),
]
HOME_ITEMS = [
    ("dollar_card.py", os.path.join(HOME, "dollar_card.py")),
    ("fonts", os.path.join(HOME, "fonts")),
]

def snap_db(src, dst):
    """Consistent snapshot of a live sqlite db. False on failure."""
    try:
        s = sqlite3.connect(f"file:{src}?mode=ro", uri=True, timeout=10)
        if os.path.exists(dst):
            os.remove(dst)
        d = sqlite3.connect(dst)
        s.backup(d)
        d.close()
        s.close()
        return True
    except Exception:
        return False


def content_hash(paths):
    """sha256 over stable source bytes (dirs walked sorted)."""
    h = hashlib.sha256()
    for arc, full in sorted(paths):
        if os.path.isdir(full):
            for root, dirs, files in os.walk(full):
                dirs.sort()
                for fn in sorted(files):
                    fp = os.path.join(root, fn)
                    h.update(os.path.relpath(fp, HERMES).encode())
                    try:
                        with open(fp, "rb") as f:
                            h.update(f.read())
                    except OSError:
                        pass
        elif os.path.isfile(full):
            h.update(arc.encode())
            try:
                with open(full, "rb") as f:
                    h.update(f.read())
            except OSError:
                pass
    return h.hexdigest()


SNAP_DIR = os.path.join(BACKUP_DIR, ".snaps")
os.makedirs(SNAP_DIR, exist_ok=True)
snap_main = os.path.join(SNAP_DIR, "main-state.db")
snap_guest = os.path.join(SNAP_DIR, "guest-state.db")
have_main = snap_db(os.path.join(HERMES, "state.db"), snap_main)
have_guest = snap_db(os.path.join(HERMES, "profiles", "guest", "state.db"), snap_guest)

GEN_FILES = {"jobs-manifest.json": manifest_path, "RESTORE.md": restore_path}

stable = [(arc, GEN_FILES.get(rel, os.path.join(HERMES, rel))) for arc, rel in ITEMS]
stable += [(arc, full) for arc, full in HOME_ITEMS]
if have_main:
    stable.append(("state/main-state.db", snap_main))
if have_guest:
    stable.append(("state/guest-state.db", snap_guest))

digest = content_hash(stable)
hash_path = os.path.join(BACKUP_DIR, ".last-hash")
try:
    prev = open(hash_path).read().strip()
except OSError:
    prev = ""
if prev == digest:
    raise SystemExit(0)  # nothing changed: silent, no delivery

with tarfile.open(out, "w:gz") as tar:
    for arc, rel in ITEMS:
        full = GEN_FILES.get(rel, os.path.join(HERMES, rel))
        if os.path.exists(full):
            tar.add(full, arcname=arc)
    for arc, full in HOME_ITEMS:
        if os.path.exists(full):
            tar.add(full, arcname=arc)
    if have_main:
        tar.add(snap_main, arcname="state/main-state.db")
    if have_guest:
        tar.add(snap_guest, arcname="state/guest-state.db")

try:
    with open(hash_path, "w") as f:
        f.write(digest)
except OSError:
    pass

backs = sorted(f for f in os.listdir(BACKUP_DIR) if f.startswith("hermes-memory-") and f.endswith(".tgz"))
for old in backs[:-84]:
    try:
        os.remove(os.path.join(BACKUP_DIR, old))
    except OSError:
        pass

print(f"MEDIA:{out}")
print(f"بکاپ کامل مهسا 🌙 | {now_teh.strftime('%Y-%m-%d %H:%M')} تهران")
