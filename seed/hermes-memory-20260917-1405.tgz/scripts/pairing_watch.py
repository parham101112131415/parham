#!/usr/bin/env python3
"""Pairing watchdog: notify home chat of NEW pending DM pairing requests.

Stdlib only. Reads the gateway pairing store directly
(~/.hermes/platforms/pairing/, legacy ~/.hermes/pairing/ if populated),
remembers already-notified request_ids in a state file, and prints a
message ONLY for newly-seen pending requests (and newly-approved users).
Empty stdout = nothing delivered (silent tick).

Approve from chat: user replies with the request-id (or the code the
stranger relays) and the agent runs:
    hermes pairing approve telegram <request-id-or-code>
"""
import json
import os
import time

HOME = os.path.expanduser("~")
HERMES = os.environ.get("HERMES_HOME") or HOME
NEW_DIR = os.path.join(HERMES, "platforms", "pairing")
OLD_DIR = os.path.join(HERMES, "pairing")
GUEST_DIRS = [
    os.path.join(HERMES, "profiles", "guest", "platforms", "pairing"),
    os.path.join(HERMES, "profiles", "guest", "pairing"),
]
STATE_PATH = os.path.join(HERMES, "pairing_watch_state.json")
TTL = 3600  # pairing codes expire after 1 hour


def _legacy_has_content(path):
    try:
        return any(os.scandir(path))
    except OSError:
        return False


def pairing_dir():
    if _legacy_has_content(OLD_DIR):
        return OLD_DIR
    return NEW_DIR


def load_json(path):
    try:
        with open(path, encoding="utf-8") as f:
            data = json.load(f)
        return data if isinstance(data, dict) else {}
    except (OSError, ValueError):
        return {}


def live_pending(pdir):
    """{request_id: {platform, user_id, user_name}} for unexpired entries."""
    out = {}
    try:
        files = os.listdir(pdir)
    except OSError:
        return out
    now = time.time()
    for fn in files:
        if not fn.endswith("-pending.json"):
            continue
        platform = fn[: -len("-pending.json")]
        for rid, info in load_json(os.path.join(pdir, fn)).items():
            if not isinstance(info, dict):
                continue
            created = info.get("created_at")
            if not isinstance(created, (int, float)):
                continue
            if now - created > TTL:
                continue
            out[str(rid)] = {
                "platform": platform,
                "user_id": str(info.get("user_id", "")),
                "user_name": str(info.get("user_name", "") or ""),
            }
    return out


def approved_ids(pdir):
    ids = set()
    try:
        files = os.listdir(pdir)
    except OSError:
        return ids
    for fn in files:
        if not fn.endswith("-approved.json"):
            continue
        for key, info in load_json(os.path.join(pdir, fn)).items():
            if isinstance(info, dict) and info.get("user_id"):
                ids.add(str(info["user_id"]))
            elif isinstance(info, str):
                ids.add(info)
            # approved file may also be a {user_id: {...}} map
            if isinstance(key, str) and key.isdigit():
                ids.add(key)
    return ids


def watch_dirs():
    dirs = [pairing_dir()]
    for d in GUEST_DIRS:
        try:
            is_dir = os.path.isdir(d)
        except OSError:
            is_dir = False
        if is_dir and d not in dirs:
            dirs.append(d)
    return dirs


def main():
    # Cron backup stays silent while the instant daemon is alive (its
    # heartbeat is fresh) so the same request is never announced twice.
    if os.environ.get("PAIRING_DAEMON") != "1":
        try:
            with open(os.path.join(HERMES, "pairing_daemon.heartbeat"),
                      encoding="utf-8") as f:
                last = int(f.read().strip())
            import time as _t
            if _t.time() - last < 120:
                return
        except (OSError, ValueError):
            pass
    pdirs = watch_dirs()
    pending = {}
    for d in pdirs:
        for rid, p in live_pending(d).items():
            if rid not in pending:
                p["scope"] = "guest" if "guest" in d else "main"
                pending[rid] = p
    state = load_json(STATE_PATH)
    known = state.get("notified", {}) if isinstance(state, dict) else {}
    if not isinstance(known, dict):
        known = {}

    new_lines = []
    for rid, p in pending.items():
        if rid not in known:
            who = f"{p['user_name']} ({p['user_id']})" if p["user_name"] else p["user_id"]
            if p.get("scope") == "guest":
                how = "hermes --profile guest pairing approve telegram"
            else:
                how = "hermes pairing approve telegram"
            new_lines.append(
                f"🔑 درخواست پیرینگ جدید — {p['platform']}: {who}\n"
                f"request-id: `{rid}`\n"
                f"برای تأیید: `{how} <request-id>` (یا کدی که طرف داده)."
            )

    # previously-notified pendings that vanished: approved or expired
    gone_lines = []
    if known:
        appr = set()
        for d in pdirs:
            appr |= approved_ids(d)
        for rid, p in known.items():
            if rid not in pending and p.get("user_id") in appr:
                who = p.get("user_name") or p.get("user_id")
                gone_lines.append(f"✅ {who} تأیید شد و الان می‌تونه با بات حرف بزنه.")

    state = {"notified": {rid: pending[rid] for rid in pending}}
    try:
        with open(STATE_PATH, "w", encoding="utf-8") as f:
            json.dump(state, f, ensure_ascii=False)
    except OSError:
        pass

    out = "\n\n".join(new_lines + gone_lines)
    if out.strip():
        print("👤 پیرینگ تلگرام:\n\n" + out)


if __name__ == "__main__":
    main()
