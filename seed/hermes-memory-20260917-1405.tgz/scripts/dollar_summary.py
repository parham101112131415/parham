#!/usr/bin/env python3
"""Midnight digest wrapper: runs fetch_dollar.py summary mode."""
import os
import runpy
import sys
sys.argv = ["fetch_dollar.py", "summary"]
_candidates = [
    os.path.expanduser("~/.hermes/scripts/fetch_dollar.py"),
    os.path.expanduser("~/scripts/fetch_dollar.py"),
    "/opt/data/scripts/fetch_dollar.py",
    "/root/.hermes/scripts/fetch_dollar.py",
]
_fetch = next((p for p in _candidates if os.path.exists(p)), _candidates[0])
runpy.run_path(_fetch, run_name="__main__")
