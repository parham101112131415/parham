#!/usr/bin/env python3
"""Instant pairing notifier daemon (3s poll).

Loops forever: runs pairing_watch.main() with stdout captured; when it
reports NEW pending requests (or newly-approved users), sends the text
straight to Parham's Telegram DM via the Bot API and touches a heartbeat
file. pairing_watch.py (cron backup) stays silent while this heartbeat
is fresh, so no double messages.

Run: nohup python3 ~/.hermes/scripts/pairing_daemon.py >> ~/.hermes/pairing_daemon.log 2>&1 &
Restart after machine/gateway reboot with the same command.
"""
import io
import json
import os
import re
import time
import urllib.parse
import urllib.request
from contextlib import redirect_stdout

import pairing_watch as pw

HOME = os.path.expanduser("~")
HERMES = os.environ.get("HERMES_HOME") or HOME
HEARTBEAT = os.path.join(HERMES, "pairing_daemon.heartbeat")
INTERVAL = 3


def _env_token():
    try:
        with open(os.path.join(HERMES, ".env"), encoding="utf-8") as f:
            for line in f:
                m = re.match(r"\s*TELEGRAM_BOT_TOKEN\s*=\s*(.+?)\s*$", line)
                if m:
                    return m.group(1).strip().strip("\"'")
    except OSError:
        pass
    return ""


def _home_chat_id():
    try:
        with open(os.path.join(HERMES, "config.yaml"), encoding="utf-8") as f:
            text = f.read()
        m = re.search(r"chat_id:\s*['\"]?(\d+)['\"]?", text)
        if m:
            return m.group(1)
    except OSError:
        pass
    return "8055210419"


def send_telegram(token, chat_id, text):
    data = urllib.parse.urlencode(
        {"chat_id": chat_id, "text": text}
    ).encode()
    req = urllib.request.Request(
        f"https://api.telegram.org/bot{token}/sendMessage", data=data)
    try:
        with urllib.request.urlopen(req, timeout=20) as r:
            body = r.read(200).decode("utf-8", "replace")
        return r.status == 200, body
    except Exception as e:  # noqa: BLE001 - log and keep looping
        return False, str(e)[:100]


def touch(path):
    try:
        with open(path, "w", encoding="utf-8") as f:
            f.write(str(int(time.time())))
    except OSError:
        pass


def main():
    pidfile = os.path.join(HERMES, "pairing_daemon.pid")
    me = str(os.getpid())
    try:
        old = open(pidfile).read().strip()
        if old and old != me:
            cl = open(f"/proc/{old}/cmdline", "rb").read().decode()
            if "pairing_daemon" in cl:
                print(f"another pairing daemon running as {old}, exiting", flush=True)
                return
    except Exception:  # noqa: BLE001
        pass
    try:
        with open(pidfile, "w") as f:
            f.write(me)
    except OSError:
        pass
    token = _env_token()
    chat_id = _home_chat_id()
    if not token:
        print("pairing_daemon: no TELEGRAM_BOT_TOKEN, exiting", flush=True)
        return
    print(f"pairing_daemon: watching every {INTERVAL}s -> {chat_id}", flush=True)
    os.environ["PAIRING_DAEMON"] = "1"
    while True:
        try:
            touch(HEARTBEAT)
            buf = io.StringIO()
            with redirect_stdout(buf):
                pw.main()
            out = buf.getvalue().strip()
            if out:
                ok, info = send_telegram(token, chat_id, out)
                print(f"sent={ok} info={info} text={out[:80]!r}", flush=True)
        except Exception as e:  # noqa: BLE001 - daemon must not die
            print(f"loop error: {str(e)[:150]}", flush=True)
        time.sleep(INTERVAL)


if __name__ == "__main__":
    main()
