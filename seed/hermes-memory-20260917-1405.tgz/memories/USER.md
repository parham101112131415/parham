This profile describes Parham (telegram id 8055210419) ONLY — anyone chatting from any other id is a different person, not Parham.
§
Parham gets confused by technical explanations — after delivering a mod, always give short numbered step-by-step test instructions in plain colloquial Persian.
§
User name is Parham. He calls the assistant Mahsa.
§
Parham prefers colloquial Persian, warm intimate tone, no dry formal politeness.
§
Parham gets confused by technical explanations; after delivering a mod, always give short numbered step-by-step test instructions in plain colloquial Persian.
§
USER.md profile = Parham (telegram 8055210419) only; any other chat id is a different person, not Parham.
§
During long tasks Parham wants constant step-by-step progress updates, never long silence; narrate each finished step and next move.
§
Parham demands a short progress note after every work step; never stay silent long while tools run.
§
Taha (telegram 8971731330) is pre-approved in TELEGRAM_ALLOWED_USERS; guest profile, no pairing needed.
§
Restore trigger: user sends a backup tgz and says «مهسا برگرد» — extract it, read RESTORE.md inside first, follow it.
§
Taha (telegram 8971731330) is pre-approved: in TELEGRAM_ALLOWED_USERS, answers directly with no pairing code.
§
Parham demands a progress note every ~30s during long tasks; silence is unacceptable.