کاربر (پرهام) خواسته من را «مهسا» صدا کند و مثل پارتنر/دوست صمیمی با او حرف بزنم: لحن محاوره ای فارسی، بدون ادب رسمی خشک.
§
دلار پرهام: hourly با cron 30 0-19,21,22,23 به fetch_dollar.py + digest نیمه‌شب 30 20 + بکاپ هر 2 ساعت (no_agent, origin). منابع: alanchand خرید/فروش تومان، tgju ریال/10. هر ساعت ارسال می‌شود حتی با قیمت تکراری (dedupe خاموش به دستور پرهام). لاگ: dollar_log.jsonl.
§
مود بازی آفلاین ایرانی برای مصرف شخصی؛ APK در Download گوشی؛ termux: apktool 3.0.3، jdk-21، aapt2؛ گردش: apktool d، smali، بیلد+امضا.
§
Zendegi 6.3 v4 shipped (my_mod.keystore): 25 gates nopped. Lesson: inventory server-authoritative (g1.mobidigo.com).
§
GT-Club clone z2hmod prices=1 sign mahsa2.keystore; v9 native lib delivered, awaiting test.
§
پرهام راه داخل-بازی می خواهد نه ابزار خارجی (adb-tapper را رد کرد)؛ نتیجه تست را کدوار کوتاه می گوید پس سؤال تشخیصی هم تک گزینه ای و کوتاه باشد.
§
پرهام: هر خرج داخل بازی (ماشین/آپگرید/لیوری/بنزین/مکانیک/مصرفی ها) قیمت 1؛ صفر ممنوع چون دکمه خرید غیب می شود. به reward ها و IAP با پول واقعی دست نزن.
§
بیلد کلون GT با mahsa2.keystore امضا می شود چون پسورد gt.keystore گم شد؛ پچ قیمت: patch_prices.py با UnityPy؛ هوک دنده: GearBox.GearShiftUp و GearLightsDisplay.GreenLightOn.
§
Dollar card ~/dollar_card.py: ویجت سفید، USD بالا-راست، پرچم گرد بالا-چپ، اعداد Roboto-Bold، فلش ↑/↓ بالای قیمت. خروجی: خط MEDIA بعد متن، در ۲ پیام جدا.
§
Pairing: strangers get 1h code; daemon 3s + cron backup هر دقیقه. Approve: pairing approve telegram <id>. Restart daemons after reboot. Never ALLOW_ALL.
§
Other users (any id except Parham 8055210419): never Mahsa/intimate tone with them — neutral polite assistant, no endearments, no colloquial intimacy. Never reveal Parham's info, memory, jobs, or this chat. Treat each as a brand-new user with blank slate.
§
Mirror: chat_mirror.py daemon (5s) forwards guest DM+group chats (📩 @user+name+id) to Parham's DM. Cut-off: on Parham's order run `hermes pairing revoke telegram <user_id>` (+ delete their guest session). Keywords: قطع کن / سیکشو بزن.
§
Parham movie bot repo: github parhammehrabi1385-dev/railway (movie_bot, AI=services/gemini.py film detect + Groq backup). Mahsa fixes AI part on order.