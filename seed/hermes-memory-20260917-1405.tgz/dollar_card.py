#!/usr/bin/env python3
"""iPhone-widget style dollar card. Usage: dollar_card.py <sell_now> <sell_prev> <out.png>"""
import sys

from PIL import Image, ImageDraw, ImageFont

S = 1080
M = 60
import os
_candidates = [
    os.path.expanduser("~/fonts/Roboto-Bold.ttf"),
    os.path.expanduser("~/.hermes/fonts/Roboto-Bold.ttf"),
    "/opt/data/fonts/Roboto-Bold.ttf",
    "/root/fonts/Roboto-Bold.ttf",
]
FONT_RB = next((p for p in _candidates if os.path.exists(p)), _candidates[0])
FONT_RND = next((p for p in (
    os.path.expanduser("~/fonts/Nunito-ExtraBold.ttf"),
    os.path.join(os.path.dirname(os.path.abspath(__file__)), "fonts", "Nunito-ExtraBold.ttf"),
    os.path.expanduser("~/.hermes/fonts/Nunito-ExtraBold.ttf"),
    "/opt/data/fonts/Nunito-ExtraBold.ttf",
    "/root/fonts/Nunito-ExtraBold.ttf",
) if os.path.exists(p)), "/root/fonts/Nunito-ExtraBold.ttf")


def font(path, size, wght=800):
    f = ImageFont.truetype(path, size)
    try:
        f.set_variation_by_axes([wght])
    except Exception:
        pass
    return f


def parse_num(s):
    return int(str(s).replace(",", "").strip())


def draw_flag(size):
    flag = Image.new("RGB", (size, size), (255, 255, 255))
    d = ImageDraw.Draw(flag)
    for i in range(13):
        y0 = i * size / 13
        col = (178, 34, 52) if i % 2 == 0 else (255, 255, 255)
        d.rectangle([0, y0, size, y0 + size / 13 + 1], fill=col)
    cw, ch = size * 0.42, size * 7 / 13
    d.rectangle([0, 0, cw, ch], fill=(60, 59, 110))
    for r in range(5):
        for c in range(6):
            x = cw * (c + 0.5) / 6
            y = ch * (r + 0.5) / 5
            d.ellipse([x - 4, y - 4, x + 4, y + 4], fill=(255, 255, 255))
    mask = Image.new("L", (size, size), 0)
    ImageDraw.Draw(mask).ellipse([0, 0, size, size], fill=255)
    return flag, mask


def render(sell_now, sell_prev, out_path):
    now = int(sell_now)
    prev = int(sell_prev) if sell_prev else now
    diff = now - prev

    img = Image.new("RGB", (S, S), (230, 230, 230))
    d = ImageDraw.Draw(img)
    d.rounded_rectangle([M, M, S - M, S - M], radius=120, fill=(255, 255, 255))

    flag, flag_mask = draw_flag(190)
    img.paste(flag, (M + 70, M + 80), flag_mask)

    f_t1 = font(FONT_RND, 72)
    f_t2 = font(FONT_RND, 56)
    xr = S - M - 70
    d.text((xr, M + 80), "US Dollar", font=f_t1, fill=(20, 20, 20),
           anchor="ra")
    d.text((xr, M + 175), "USD", font=f_t2, fill=(150, 150, 150), anchor="ra")

    f_price = font(FONT_RND, 135)
    price_txt = "{:,}".format(now)
    pr_y = S - M - 270
    d.text((S // 2 - 90, pr_y), price_txt, font=f_price,
           fill=(20, 20, 20), anchor="ma")

    f_ch = font(FONT_RND, 92)
    if diff > 0:
        col = (22, 163, 74)
        tri_up = True
    elif diff < 0:
        col = (220, 38, 38)
        tri_up = False
    else:
        col = (150, 150, 150)
        tri_up = None
    _a = abs(diff)
    if _a >= 1000:
        ch_txt = ("%.2f" % (_a / 1000)).rstrip("0").rstrip(".") + "K"
    else:
        ch_txt = "{:,}".format(_a)
    arr_w, arr_h, lw = 52, 66, 9
    nb = d.textbbox((0, 0), ch_txt, font=f_ch)
    nh = nb[3] - nb[1]
    gap, total_w = 14, arr_w + 14 + (nb[2] - nb[0])
    ch_y = pr_y - 135
    sx = S // 2 - 250 - total_w // 2
    ay = ch_y + (nh - arr_h) // 2 + 8 + 7
    cx = sx + arr_w // 2
    r = lw // 2
    def _dot(x, y):
        d.ellipse([x - r, y - r, x + r, y + r], fill=col)
    if tri_up is None:
        d.line([(sx, ay + arr_h // 2), (sx + arr_w, ay + arr_h // 2)],
               fill=col, width=lw)
        _dot(sx, ay + arr_h // 2)
        _dot(sx + arr_w, ay + arr_h // 2)
    elif tri_up:
        d.line([(cx, ay), (cx, ay + arr_h)], fill=col, width=lw)
        d.line([(cx, ay), (cx - 23, ay + 16)], fill=col, width=lw, joint="curve")
        d.line([(cx, ay), (cx + 23, ay + 16)], fill=col, width=lw, joint="curve")
        _dot(cx, ay)
        _dot(cx - 23, ay + 16)
        _dot(cx + 23, ay + 16)
        _dot(cx, ay + arr_h)
    else:
        d.line([(cx, ay), (cx, ay + arr_h)], fill=col, width=lw)
        d.line([(cx, ay + arr_h), (cx - 23, ay + arr_h - 16)], fill=col, width=lw, joint="curve")
        d.line([(cx, ay + arr_h), (cx + 23, ay + arr_h - 16)], fill=col, width=lw, joint="curve")
        _dot(cx, ay + arr_h)
        _dot(cx - 23, ay + arr_h - 16)
        _dot(cx + 23, ay + arr_h - 16)
        _dot(cx, ay)
    ax = sx + arr_w + gap
    d.text((ax, ch_y), ch_txt, font=f_ch, fill=col)

    img.save(out_path)


if __name__ == "__main__":
    a_now = parse_num(sys.argv[1])
    a_prev = parse_num(sys.argv[2]) if len(sys.argv) > 2 else a_now
    a_out = sys.argv[3] if len(sys.argv) > 3 else "/root/.hermes/dollar/dollar_card.png"
    render(a_now, a_prev, a_out)
