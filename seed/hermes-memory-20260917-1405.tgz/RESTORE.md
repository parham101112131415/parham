Restore trigger: user sends this tgz and says «مهسا برگرد» (or asks to restore from backup).
1. Extract tgz to a temp dir.
2. Copy memories/USER.md + memories/MEMORY.md -> ~/.hermes/memories/ (also load each § section into the memory tool).
3. Copy SOUL.md -> ~/.hermes/SOUL.md (only if user confirms overwrite).
4. Copy skills/* -> ~/.hermes/skills/ (merge, keep existing).
5. Copy scripts/* -> ~/.hermes/scripts/ ; dollar/* -> ~/.hermes/dollar/ ; dollar_card.py + fonts/ -> home dir.
6. state/main-state.db + state/guest-state.db are session snapshots (restore only with gateway stopped, ask first).
7. .env + config.yaml: restore ONLY on a new machine / explicit user order (they hold secrets + model config).
8. Recreate cron jobs from jobs-manifest.json (no_agent, deliver=origin, attach) unless they already exist.
9. Verify: py_compile scripts, test-run memory_backup.py (2nd run must be silent), report what was restored.
